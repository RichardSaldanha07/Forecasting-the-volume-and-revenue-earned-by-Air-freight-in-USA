# Applying the Time Series Forecasting models,test and perfoming analysis on Domestic Cargo for both of its measures 
# which are ATM (Available Ton Miles) and Revenue FTM (Freight Ton Miles) respectively

# Domestic Cargo 

# Applying "gglagplot" against lagged versions of themselves. 
# Which helps in visualising 'auto-dependence' even when auto-correlations vanish.


# Available Ton Miles
Domestic_Cargo_ATM_lagplot <- gglagplot(Domestic_Cargo_ATM) + 
  ggtitle("Lag Plot : Domestic Cargo - Available Ton Miles (January 2000 - February 2020)")
Domestic_Cargo_ATM_lagplot

# Freight Ton Miles
Domestic_Cargo_FTM_lagplot <- gglagplot(Domestic_Cargo_FTM) + 
  ggtitle("Lag Plot : Domestic Cargo - Revenue Freight Ton Miles (January 2000 - February 2020)")

Domestic_Cargo_FTM_lagplot

# Domestic Cargo Records
Domestic_Cargo_lagplot <- gglagplot(Data_Domestic_Cargo_Plot) +
  ggtitle(" Lag Plot : Domestic Cargo Records (January 2000 - February 2020)")

Domestic_Cargo_lagplot


# Applying the test of Autocorrelation 
# Applying the correlations associated with the lag plots form 
#what is called the autocorrelation function (ACF).


# Available Ton Miles
Domestic_Cargo_ATM_acfplot<- ggAcf(Domestic_ATM_Diff) + 
  ggtitle("ACF Plot : Domestic Cargo - Available Ton Miles (January 2000 - February 2020)")
Domestic_Cargo_ATM_acfplot
 
# Freight Ton Miles
Domestic_Cargo_FTM_acfplot <- ggAcf(Domestic_FTM_Diff) + 
  ggtitle("ACF Plot : Domestic Cargo - Revenue Freight Ton Miles (January 2000 - February 2020)")

Domestic_Cargo_FTM_acfplot


# Domestic Cargo Records
Domestic_Cargo_acfplot <- ggAcf(Diff_Domestic_Cargo) +
  ggtitle(" ACF Plot : Domestic Cargo (January 2000 - February 2020)")
  
Domestic_Cargo_acfplot


# Note: The Box test can be applied only to the univariate time series analysis.

# Available Ton Miles
Domestic_Cargo_ATM_Boxtest <- Box.test(Domestic_ATM_Diff, lag = 16, type = "Ljung")

Domestic_Cargo_ATM_Boxtest

# Freight Ton Miles
Domestic_Cargo_FTM_Boxtest <- Box.test(Domestic_FTM_Diff, lag = 16, type = "Ljung")

Domestic_Cargo_FTM_Boxtest

# Splitting the Dataset into Training and Testing Data


# Availabe Ton Miles
split_Domestic_Cargo_ATM <- ts_split(Domestic_Cargo_ATM, sample.out = 30)

Trainingdata_Domestic_Cargo_ATM  <- split_Domestic_Cargo_ATM$train
Testingdata_Domestic_Cargo_ATM <- split_Domestic_Cargo_ATM$test

# Checking the length
length(Domestic_Cargo_ATM)
length(Trainingdata_Domestic_Cargo_ATM)
length(Testingdata_Domestic_Cargo_ATM)


# In order to check whether the data frame is of time series object we make use of the is.ts() function
# It returns a boolean results in which True indicate a time series object and False indicates a non time series object

# Domestic Cargo Available Ton Miles
is.ts(Domestic_Cargo_ATM) # Time Series Data object

# Training Data of Domestic Cargo Available Ton Miles
is.ts(Trainingdata_Domestic_Cargo_ATM) # Time Series Data object

# Testing Data of Domestic Cargo Available Ton Miles
is.ts(Testingdata_Domestic_Cargo_ATM) # Time Series Data object



# Freight Ton Miles
split_Domestic_Cargo_FTM <- ts_split(Domestic_Cargo_FTM, sample.out = 30)

Trainingdata_Domestic_Cargo_FTM  <- split_Domestic_Cargo_FTM$train
Testingdata_Domestic_Cargo_FTM <- split_Domestic_Cargo_FTM$test

# Checking the length
length(Domestic_Cargo_FTM)
length(Trainingdata_Domestic_Cargo_FTM)
length(Testingdata_Domestic_Cargo_FTM)


# In order to check whether the data frame is of time series object we make use of the is.ts() function
# It returns a boolean results in which True indicate a time series object and False indicates a non time series object

# # Domestic Cargo Freight Ton Miles
is.ts(Domestic_Cargo_FTM) # Time Series Data object

# Training Data of Domestic Cargo Freight Ton Miles
is.ts(Trainingdata_Domestic_Cargo_FTM) # Time Series Data object

# Testing Data of Domestic Cargo Freight Ton Miles
is.ts(Testingdata_Domestic_Cargo_FTM) # Time Series Data object


# Domestic Cargo Records
split_Domestic_Cargo<- ts_split(Data_Domestic_Cargo_Plot, sample.out = 30)

Trainingdata_Domestic_Cargo  <- split_Domestic_Cargo$train
Testingdata_Domestic_Cargo <- split_Domestic_Cargo$test

# Checking the length
length(Data_Domestic_Cargo_Plot)
length(Trainingdata_Domestic_Cargo)
length(Testingdata_Domestic_Cargo)


# In order to check whether the data frame is of time series object we make use of the is.ts() function
# It returns a boolean results in which True indicate a time series object and False indicates a non time series object

# Domestic Cargo Records
is.ts(Data_Domestic_Cargo_Plot) # Time Series Data object

# Training Data of Domestic Cargo Records
is.ts(Trainingdata_Domestic_Cargo) # Time Series Data object

# Testing Data of Domestic Cargo Records
is.ts(Testingdata_Domestic_Cargo) # Time Series Data object


# Applying the Naive Method
# Note: Naive Method simply uses the most recent observation as the forecast for future observation.
# Note: The darker region is an 80% interval, and the lighter region is a 95% interval
# 80% forecast intervals should contain 80% of future observations.
# 95% forecast intervals should contain 95% of future observations.
# The default plot for forecast in R looks like this with both 80% and 95% region shown.
# We can check the residuals only for univariate time series analysis

# Availabe Ton Miles - Forecast for the next 5 years
Domestic_Cargo_ATM_naiveplot <- naive(Trainingdata_Domestic_Cargo_ATM, h = 60)

# Creating the plot
autoplot(Domestic_Cargo_ATM_naiveplot) + 
  ggtitle("Naive Plot : Domestic Cargo - Available Ton Miles (January 2000 - February 2020)") +
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")
  

#  Checking the Summary
summary(Domestic_Cargo_ATM_naiveplot)

# Checking the residuals
checkresiduals(Domestic_Cargo_ATM_naiveplot) #Not a white noise data


# Freight Ton Miles - Forecast for the next 5 years
Domestic_Cargo_FTM_naiveplot <- naive(Trainingdata_Domestic_Cargo_FTM, h = 60)

# Creating the Plot
autoplot(Domestic_Cargo_FTM_naiveplot) + 
  ggtitle("Naive Plot: Domestic Cargo - Revenue Freight Ton Miles (January 2000 - February 2020)") +
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")

# Checking the Summary
summary(Domestic_Cargo_FTM_naiveplot)

# Checking the residuals
checkresiduals(Domestic_Cargo_FTM_naiveplot) #Not a white noise data


# Domestic Cargo Records - Forecast for the next 5 years
Domestic_Cargo_naiveplot <- naive(Trainingdata_Domestic_Cargo, h = 60)

# Creating the Plot
autoplot(Domestic_Cargo_naiveplot) + 
  ggtitle("Naive Plot: Domestic Cargo Records (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total Volume and Revenue earned by Domestic Cargo")

# Checking the summary
summary(Domestic_Cargo_naiveplot)



# Applying the Seasonal naive Method
# Note: we set each forecast to be equal to the last observed value from the same season of the year (e.g., the same month of the previous year).

# Available Ton Miles - Forecasting for the next 5 years
Domestic_Cargo_ATM_snaiveplot <- snaive(Trainingdata_Domestic_Cargo_ATM, h = 60)

# Creating the Plot
autoplot(Domestic_Cargo_ATM_snaiveplot) + 
  ggtitle("Seasonal Naive Plot: Domestic Cargo - Available Ton Miles (January 2000 - February 2020)") +
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")

# Checking the Summary
summary(Domestic_Cargo_ATM_snaiveplot)

# Checking the residuals
checkresiduals(Domestic_Cargo_ATM_snaiveplot) # Not a white Noise Data


# Freight Ton Miles - Forecasting for the next 5 years
Domestic_Cargo_FTM_snaiveplot <- snaive(Trainingdata_Domestic_Cargo_FTM, h = 60)


# Creating the Plot
autoplot(Domestic_Cargo_FTM_snaiveplot) + 
  ggtitle("Seasonal Naive Plot: Domestic Cargo - Revenue Freight Ton Miles (January 2000 - February 2020)") +
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")


# Checking the Summary
summary(Domestic_Cargo_FTM_snaiveplot)


# Checking the residuals
checkresiduals(Domestic_Cargo_FTM_snaiveplot) # Not a white noise data


# Domestic Cargo Records - Forecasting for the next 5 years
Domestic_Cargo_snaiveplot <- snaive(Trainingdata_Domestic_Cargo, h = 60)

# Creating the plot
autoplot(Domestic_Cargo_snaiveplot) + 
  ggtitle("Seasonal Naive Plot: Domestic Cargo Records (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total Volume and Revenue earned by Domestic Cargo")

# Checking the Summary
summary(Domestic_Cargo_snaiveplot)


# Applying the Mean Plot
# Note: the forecasts of all future values are equal to the average (or "mean") of the historical data.


# Available Ton Miles - Forecasting for the next 5 years
Domestic_Cargo_ATM_meanplot <- meanf(Trainingdata_Domestic_Cargo_ATM, h = 60)


# Creating the Plot
autoplot(Domestic_Cargo_ATM_meanplot) + 
  ggtitle("Mean Plot: Domestic Cargo - Available Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")


# Checking the Summary
summary(Domestic_Cargo_ATM_meanplot)

# Checking the residuals
checkresiduals(Domestic_Cargo_ATM_meanplot) #Not a white noise data


# Freight Ton Miles - Forecasting for the next 5 years
Domestic_Cargo_FTM_meanplot <- meanf(Trainingdata_Domestic_Cargo_FTM, h = 60)

# Creating the Plot
autoplot(Domestic_Cargo_FTM_meanplot) + 
  ggtitle("Mean Plot: Domestic Cargo - Revenue Freight Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")


# Checking the Summary
summary(Domestic_Cargo_FTM_meanplot)

# Checking the residuals
checkresiduals(Domestic_Cargo_FTM_meanplot) # Not a white noise data


# From the Naive Method and Snaive Method we see that there is no white noise in the data
# Since p < 0.05


# Comparing Accuracy of Naive, SNaive and Mean method by checking for the RMSE value 

# Available Ton Miles
accuracy(Domestic_Cargo_ATM_naiveplot, Testingdata_Domestic_Cargo_ATM)

accuracy(Domestic_Cargo_ATM_snaiveplot, Testingdata_Domestic_Cargo_ATM)

accuracy(Domestic_Cargo_ATM_meanplot, Testingdata_Domestic_Cargo_ATM)

# Saving the best forecast method for Available Ton Miles 

Domestic_Cargo_ATM_naive_snaive_mean_best <- Domestic_Cargo_ATM_naiveplot

Domestic_Cargo_ATM_naive_snaive_mean_best

# Plotting the best forecast model

autoplot(Domestic_Cargo_ATM_naive_snaive_mean_best) +
  ggtitle("Best Plot Naive Plot : Domestic Cargo - Available Ton Miles (January 2000 - February 2020)") +
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")



# Freight Ton Miles
accuracy(Domestic_Cargo_FTM_naiveplot, Testingdata_Domestic_Cargo_FTM)

accuracy(Domestic_Cargo_FTM_snaiveplot, Testingdata_Domestic_Cargo_FTM)

accuracy(Domestic_Cargo_FTM_meanplot, Testingdata_Domestic_Cargo_FTM)

# Saving the best forecast method for Frieght Ton Miles

Domestic_Cargo_FTM_naive_snaive_mean_best <- Domestic_Cargo_FTM_naiveplot

# Plotting the best forecast model


autoplot(Domestic_Cargo_FTM_naive_snaive_mean_best) +
  ggtitle("Best Plot Naive Plot : Domestic Cargo - Revenue Freight Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")


# Applying the Time Series Cross Validation for Available Ton Miles

# Compute cross-validated errors for up to 10 steps ahead
Domestic_Cargo_ATM_error <- tsCV(Trainingdata_Domestic_Cargo_ATM, forecastfunction = naive, h = 10)
Domestic_Cargo_ATM_error

# Compute the MSE values and remove missing values
Domestic_Cargo_ATM_mse <- colMeans(Domestic_Cargo_ATM_error^2, na.rm = TRUE)
Domestic_Cargo_ATM_mse

# Plot the MSE values against the forecast horizon
Domestic_Cargo_ATM_TimeSeriesCrossValidationPlot <- data.frame(h = 1:10, MSE = Domestic_Cargo_ATM_mse) %>%
  ggplot(aes(x = h, y = MSE)) + 
  geom_point() + 
  ggtitle("Time Series Cross Validation Plot : Domestic Cargo Available Ton Miles (January 2000 - February 2020)") +
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")
  

Domestic_Cargo_ATM_TimeSeriesCrossValidationPlot

# Applying the Time Series Cross Validation for Freight Ton Miles

# Compute cross-validated errors for up to 10 steps ahead
Domestic_Cargo_FTM_error <- tsCV(Trainingdata_Domestic_Cargo_FTM, forecastfunction = naive, h = 10)
Domestic_Cargo_FTM_error

# Compute the MSE values and remove missing values
Domestic_Cargo_FTM_mse <- colMeans(Domestic_Cargo_FTM_error^2, na.rm = TRUE)
Domestic_Cargo_FTM_mse

# Plot the MSE values against the forecast horizon
Domestic_Cargo_FTM_TimeSeriesCrossValidationPlot <- data.frame(h = 1:10, MSE = Domestic_Cargo_FTM_mse) %>%
  ggplot(aes(x = h, y = MSE)) + 
  geom_point() + 
  ggtitle("Time Series Cross Validation Plot : Domestic Cargo Revenue Freight Ton Miles (January 2000 - February 2020)") +
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")

Domestic_Cargo_FTM_TimeSeriesCrossValidationPlot


# Applying Simple Exponential Smoothing Method to Availabe Ton Miles for forecasting for next 5 years

Domestic_Cargo_ATM_sesplot <- ses(Trainingdata_Domestic_Cargo_ATM, h = 60)

Domestic_Cargo_ATM_sesplot

# Checking the summary of the model
summary(Domestic_Cargo_ATM_sesplot)

# Creating the Plot

autoplot(Domestic_Cargo_ATM_sesplot) +
  ggtitle("Simple Exponential Smoothing Plot: Domestic Cargo Available Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")


# Add the one-step forecasts for the training data to the plot
autoplot(Domestic_Cargo_ATM_sesplot) + 
  autolayer(fitted(Domestic_Cargo_ATM_sesplot)) +
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")


# Applying Simple Exponential Smoothing Method to Freight Ton Miles for forecasting for the next 5 years

Domestic_Cargo_FTM_sesplot <- ses(Trainingdata_Domestic_Cargo_FTM, h = 60)

Domestic_Cargo_FTM_sesplot

# Checking the summary of the model
summary(Domestic_Cargo_FTM_sesplot)

# Creating the Plot

autoplot(Domestic_Cargo_FTM_sesplot) +
  ggtitle("Simple Exponential Smoothing Plot: Domestic Cargo Revenue Freight Ton Miles (January 2000 - February 2020)") +
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")


# Add the one-step forecasts for the training data to the plot
autoplot(Domestic_Cargo_FTM_sesplot) + 
  autolayer(fitted(Domestic_Cargo_FTM_sesplot)) +
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")


# Compare Simple Exponential Smoothing (SES) and Naive Forecast Accuracy
# Note: Pick a measure in the output, such as RMSE or MAE, 
#to evaluate the forecast(s); a smaller error indicates higher accuracy.

# Available Ton Miles
accuracy(Domestic_Cargo_ATM_sesplot, Testingdata_Domestic_Cargo_ATM)
accuracy(Domestic_Cargo_ATM_naiveplot, Testingdata_Domestic_Cargo_ATM)


# Saving the best forecast method for Available Ton Miles

Domestic_Cargo_ATM_ses_naive_best <- Domestic_Cargo_ATM_naiveplot

Domestic_Cargo_ATM_ses_naive_best


# Ploting the best forecasting method for Available Ton Miles
autoplot(Domestic_Cargo_ATM_ses_naive_best) + 
  ggtitle("Best Plot: Naive Plot : Domestic Cargo - Available Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")



# Freight Ton Miles

accuracy(Domestic_Cargo_FTM_sesplot, Testingdata_Domestic_Cargo_FTM)
accuracy(Domestic_Cargo_FTM_naiveplot, Testingdata_Domestic_Cargo_FTM)

# Saving the best forecast method for Freight Ton Miles

Domestic_Cargo_FTM_ses_naive_best <- Domestic_Cargo_FTM_naiveplot

Domestic_Cargo_FTM_ses_naive_best

# Ploting the best forecasting method for Freight Ton Miles
autoplot(Domestic_Cargo_FTM_ses_naive_best) + 
  ggtitle(" Best Plot: Naive Plot: Domestic Cargo - Revenue Freight Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")




# Exponential Smoothing methods with trend


# Applying the Holt's Linear trend Method for Available Ton Miles Data For Forecasting for the next 5 years

Domestic_Cargo_ATM_holtplot <- holt(Trainingdata_Domestic_Cargo_ATM, h = 60)
Domestic_Cargo_ATM_holtplot

# Checking the summary of the model

summary(Domestic_Cargo_ATM_holtplot)

# Checking the residuals
checkresiduals(Domestic_Cargo_ATM_holtplot)  # Not a white Noise Data


# Ploting the forecast model

autoplot(Domestic_Cargo_ATM_holtplot) +
  ggtitle("Holt Linear Trend : Domestic Cargo - Available Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")



# Applying the Holt's Linear trend Method for Freight Ton Miles Data - For Forecasting for next 5 years

Domestic_Cargo_FTM_holtplot <- holt(Trainingdata_Domestic_Cargo_FTM, h = 60)
Domestic_Cargo_FTM_holtplot

# Checking the summary of the model

summary(Domestic_Cargo_FTM_holtplot)


# Checking the residuals
checkresiduals(Domestic_Cargo_FTM_holtplot)   #Not a white noise data

# Ploting the forecast model

autoplot(Domestic_Cargo_FTM_holtplot) + 
  ggtitle("Holt Linear Trend : Domestic Cargo - Revenue Freight Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")



# Holt-Winters with monthly data

# Plotting the Training data for Available Ton Miles
autoplot(Trainingdata_Domestic_Cargo_ATM) +
  ggtitle("Training Data of Domestic Cargo - Available Ton Miles Jan 2000 to Aug 2017") +
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")

# Applying the Holt's Winter trend Method for Available Ton Miles Data to produce a forecast of 5 years

Domestic_Cargo_ATM_holtwinterplot <- hw(Trainingdata_Domestic_Cargo_ATM, seasonal = "additive", h = 17)
Domestic_Cargo_ATM_holtwinterplot


# Checking for residuals look like white noise

checkresiduals(Domestic_Cargo_ATM_holtwinterplot)

Domestic_Cargo_ATM_whitenoise <- FALSE

Domestic_Cargo_ATM_whitenoise

# Ploting the forecast

autoplot(Domestic_Cargo_ATM_holtwinterplot) +
  ggtitle("Holt's Winter Trend : Domestic Cargo - Available Ton Miles (January 2000 - February 2020)") +
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")



# Holt-Winters with monthly data

# Plotting the Training data for Freight Ton Miles
autoplot(Trainingdata_Domestic_Cargo_FTM) +
  ggtitle("Training Data of Domestic Cargo - Revenue Freight Ton Miles Jan 2000 to Aug 2017") +
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")

# Applying the Holt's Winter trend Method for Freight Ton Miles Data to produce a forecast of 5 years

Domestic_Cargo_FTM_holtwinterplot <- hw(Trainingdata_Domestic_Cargo_FTM, seasonal = "additive", h = 17)
Domestic_Cargo_FTM_holtwinterplot


# Checking for residuals look like white noise

checkresiduals(Domestic_Cargo_FTM_holtwinterplot)

Domestic_Cargo_FTM_whitenoise <- FALSE

Domestic_Cargo_FTM_whitenoise

# Ploting the forecast

autoplot(Domestic_Cargo_FTM_holtwinterplot) +
  ggtitle("Holt's Winter Trend : Domestic Cargo - Revenue Freight Ton Miles (January 2000 - February 2020)") +
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")



# Comparing the accuracy of Holt's Linear, Holt's Winter and Naive Method for Available Ton Miles

accuracy(Domestic_Cargo_ATM_holtplot, Testingdata_Domestic_Cargo_ATM)
accuracy(Domestic_Cargo_ATM_holtwinterplot, Testingdata_Domestic_Cargo_ATM)
accuracy(Domestic_Cargo_ATM_naiveplot, Testingdata_Domestic_Cargo_ATM)


# Saving the best forecast method for Available Ton Miles

Domestic_Cargo_ATM_holt_holtwinter_naive_best <- Domestic_Cargo_ATM_holtwinterplot

  
# Plotting the best accuracy plot

autoplot(Domestic_Cargo_ATM_holt_holtwinter_naive_best) +
  ggtitle(" Best Plot: Holt's Winter Trend : Domestic Cargo - Available Ton Miles (January 2000 - February 2020)") +
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")


# Comparing the accuracy of Holt's Linear, Holt's Winter and Naive Method for Freight Ton Miles

accuracy(Domestic_Cargo_FTM_holtplot, Testingdata_Domestic_Cargo_FTM)
accuracy(Domestic_Cargo_FTM_holtwinterplot, Testingdata_Domestic_Cargo_FTM)
accuracy(Domestic_Cargo_FTM_naiveplot, Testingdata_Domestic_Cargo_FTM)


# Saving the best forecast method for Freight Ton Miles

Domestic_Cargo_FTM_holt_holtwinter_naive_best <- Domestic_Cargo_FTM_holtwinterplot



# Plotting the best accuracy plot

autoplot(Domestic_Cargo_FTM_holt_holtwinter_naive_best) +
  ggtitle(" Best Plot: Holt's Winter Trend : Domestic Cargo - Revenue Freight Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")




# State Space Models for Exponential Smoothing

# Fit the ETS model to training data of domestic cargo ATM
Domestic_Cargo_ATM_etsplot <- ets(Trainingdata_Domestic_Cargo_ATM)

Domestic_Cargo_ATM_etsplot  #ETS(A,Ad,A)

# Check the residuals
checkresiduals(Domestic_Cargo_ATM_etsplot)  # not white noise data.


# Plot the forecast
autoplot(forecast(Domestic_Cargo_ATM_etsplot)) +
  ggtitle("ETS Plot: Domestic Cargo - Available Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")



# Fit the ETS model to training data of domestic cargo FTM
Domestic_Cargo_FTM_etsplot <- ets(Trainingdata_Domestic_Cargo_FTM)

Domestic_Cargo_FTM_etsplot  #ETS(A,N,A)

# Check the residuals
checkresiduals(Domestic_Cargo_FTM_etsplot)  # not white noise data.


# Plot the forecast
autoplot(forecast(Domestic_Cargo_FTM_etsplot)) +
  ggtitle("ETS Plot: Domestic Cargo - Freight Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")



# comparison between ETS vs seasonal naive method for Domestic Cargo- Available Ton Miles

# Function to return ETS forecasts
Domestic_Cargo_ATM_fets <- function(y, h) {
  forecast(ets(y), h = h)
}


# Apply tsCV() for both methods by computing cross-validated errors for up to 10 steps ahead
Domestic_Cargo_ATM_tscv_ets_plot <- tsCV(Trainingdata_Domestic_Cargo_ATM, Domestic_Cargo_ATM_fets, h = 10)

autoplot(Domestic_Cargo_ATM_tscv_ets_plot) +
  ggtitle("Time Series Cross Validation with ETS Plot : Domestic Cargo Available Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")


Domestic_Cargo_ATM_tscv_snaive_plot <- tsCV(Trainingdata_Domestic_Cargo_ATM, snaive, h= 10)
autoplot(Domestic_Cargo_ATM_tscv_snaive_plot) +
  ggtitle("Time Series Cross Validation with Seasonal Naive Plot : Domestic Cargo Available Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")

# Compute MSE of resulting errors for Domestic Cargo ATM (watch out for missing values)
mean(Domestic_Cargo_ATM_tscv_ets_plot^2, na.rm = TRUE)
mean(Domestic_Cargo_ATM_tscv_snaive_plot^2, na.rm = TRUE)

# Saving the best forecast method for Available Ton Miles

Domestic_Cargo_ATM_tscv_ets_snaive_bestplot <- Domestic_Cargo_ATM_tscv_ets_plot


autoplot(Domestic_Cargo_ATM_tscv_ets_snaive_bestplot) +
  ggtitle("Time Series Cross Validation with ETS Plot : Domestic Cargo Available Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")



# comparison between ETS vs seasonal naive method for Domestic Cargo- Freight Ton Miles

# Function to return ETS forecasts
Domestic_Cargo_FTM_fets <- function(y, h) {
  forecast(ets(y), h = h)
}


# Apply tsCV() for both methods by computing cross-validated errors for up to 10 steps ahead
Domestic_Cargo_FTM_tscv_ets_plot <- tsCV(Trainingdata_Domestic_Cargo_FTM, Domestic_Cargo_FTM_fets, h = 10)

autoplot(Domestic_Cargo_FTM_tscv_ets_plot) +
  ggtitle("Time Series Cross Validation with ETS Plot : Domestic Cargo Revenue Freight Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")


Domestic_Cargo_FTM_tscv_snaive_plot <- tsCV(Trainingdata_Domestic_Cargo_FTM, snaive, h= 10)
autoplot(Domestic_Cargo_FTM_tscv_snaive_plot) +
  ggtitle("Time Series Cross Validation with Seasonal Naive Plot : Domestic Cargo Revenue Freight Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")

# Compute MSE of resulting errors for Domestic Cargo FTM (watch out for missing values)
mean(Domestic_Cargo_FTM_tscv_ets_plot^2, na.rm = TRUE)
mean(Domestic_Cargo_FTM_tscv_snaive_plot^2, na.rm = TRUE)

# Saving the best forecast method for Freight Ton Miles

Domestic_Cargo_FTM_tscv_ets_snaive_bestplot <- Domestic_Cargo_FTM_tscv_snaive_plot


autoplot(Domestic_Cargo_FTM_tscv_ets_snaive_bestplot) +
  ggtitle("Time Series Cross Validation with Seasonal Naive Plot : Domestic Cargo Revenue Freight Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")



# Box-Cox transformations for time series

# Plotting the Training data for Available Ton Miles
autoplot(Trainingdata_Domestic_Cargo_ATM) +
  ggtitle("Training Data of Domestic Cargo - Available Ton Miles Jan 2000 to Aug 2017") +
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")

Domestic_Cargo_ATM_BoxCoxtest <- BoxCox.lambda(Trainingdata_Domestic_Cargo_ATM)

Domestic_Cargo_ATM_BoxCoxtest # Close to lambda = 1 is essentially no transformation- It simply subtracts one from all observations.

# Plotting the Training data for Freight Ton Miles
autoplot(Trainingdata_Domestic_Cargo_FTM) +
  ggtitle("Training Data of Domestic Cargo - Revenue Freight Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")

Domestic_Cargo_FTM_BoxCoxtest <- BoxCox.lambda(Trainingdata_Domestic_Cargo_FTM)

Domestic_Cargo_FTM_BoxCoxtest # Lambda equals 1 is essentially no transformation- It simply subtracts one from all observations.


# Non- Seasonal differencing for Stationarity

# Plotting the Training data for Available Ton Miles
autoplot(Trainingdata_Domestic_Cargo_ATM) +
  ggtitle("Training Data of Domestic Cargo - Available Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")


# Plot the differenced data for Available Ton Miles

autoplot(diff(Trainingdata_Domestic_Cargo_ATM)) +
  ggtitle("Difference : Training Data of Domestic Cargo - Available Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")


# Plotting the ACF of the differenced data for Available Ton Miles

ggAcf(diff(Trainingdata_Domestic_Cargo_ATM)) +
  ggtitle("ACF Plot: Domestic Cargo ATM")   #Not a white noise data.
 

# Non- Seasonal differencing for Stationarity

# Plotting the Training data for Freight Ton Miles
autoplot(Trainingdata_Domestic_Cargo_FTM) +
  ggtitle("Training Data of Domestic Cargo - Revenue Freight Ton Miles Jan 2000 to Aug 2017") +
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")


# Plot the differenced data for Freight Ton Miles

autoplot(diff(Trainingdata_Domestic_Cargo_FTM)) +
  ggtitle(" Difference: Training Data of Domestic Cargo - Revenue Freight Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")

# Plotting the ACF of the differenced data for Freight Ton Miles

ggAcf(diff(Trainingdata_Domestic_Cargo_FTM)) +
  ggtitle("ACF Plot: Domestic Cargo FTM")  #Not a white noise data.




# Seasonal differencing for stationarity - Available Ton Miles

# Plotting the Training data for Available Ton Miles
autoplot(Trainingdata_Domestic_Cargo_ATM) +
  ggtitle("Training Data of Domestic Cargo - Available Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")



# Take logs and seasonal differences of training data of Domestic Cargo Available Ton Miles
Domestic_Cargo_ATM_diff_logplot <- diff(log(Trainingdata_Domestic_Cargo_ATM), lag = 12)

# Plotting the Data
autoplot(Domestic_Cargo_ATM_diff_logplot) +
  ggtitle("Difference Log Plot: Training Data of Domestic Cargo - Available Ton Miles Jan 2000 to Aug 2017") +
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")

# Take another difference and plot
Domestic_Cargo_ATM_difflog_plot <- diff(Domestic_Cargo_ATM_diff_logplot)

autoplot(Domestic_Cargo_ATM_difflog_plot) +
  ggtitle(" Second Difference Plot: Training Data of Domestic Cargo - Available Ton Miles Jan 2000 to Aug 2017") +
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")


# Plotting the ACF of the data
ggAcf(Domestic_Cargo_ATM_difflog_plot) + #Not white noise data
  ggtitle("ACF plot of the difference of the logs and seasonal differences of training data of Domestic Cargo Available Ton Miles")
  

# Seasonal differencing for stationarity - Freight Ton Miles

# Plotting the Training data for Freight Ton Miles
autoplot(Trainingdata_Domestic_Cargo_FTM) +
  ggtitle("Training Data of Domestic Cargo - Revenue Freight Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")



# Take logs and seasonal differences of training data of Domestic Cargo Freight Ton Miles
Domestic_Cargo_FTM_diff_logplot <- diff(log(Trainingdata_Domestic_Cargo_FTM), lag = 12)

# Plotting the Data
autoplot(Domestic_Cargo_FTM_diff_logplot) +
  ggtitle("Difference Log Plot: Training Data of Domestic Cargo - Revenue Freight Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")

# Take another difference and plot
Domestic_Cargo_FTM_difflog_plot <- diff(Domestic_Cargo_FTM_diff_logplot)

autoplot(Domestic_Cargo_FTM_difflog_plot) +
  ggtitle(" Second Difference Plot: Training Data of Domestic Cargo - Revenue Freight Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")


# Plotting the ACF of the data
ggAcf(Domestic_Cargo_FTM_difflog_plot) +
  ggtitle("ACF plot of the difference of the logs and seasonal differences of training data of Domestic Cargo Freight Ton Miles")  #Not white noise data
  


# Automatic ARIMA models for seasonal time series S-ARIMA (p,d,q)(P,D,Q)[m]

#  Check that the logged training data of Domestic Cargo Available Ton Miles have a stable variance


Domestic_Cargo_ATM_logplot <- autoplot(log(Trainingdata_Domestic_Cargo_ATM)) +
  ggtitle("Log Plot: Domestic Cargo - Available Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")

Domestic_Cargo_ATM_logplot

# Fit a seasonal ARIMA model to data with lambda = 0


Domestic_Cargo_ATM_autoarimaplot <- auto.arima(Trainingdata_Domestic_Cargo_ATM, lambda = 0)

Domestic_Cargo_ATM_autoarimaplot

# Checking the summary of the model

summary(Domestic_Cargo_ATM_autoarimaplot)


# Recording the amount of lag-1 differencing and seasonal differencing used
Domestic_Cargo_ATM_d <- 2
Domestic_Cargo_ATM_D <- 0


# Plotting the Forecast for the next 2 years

autoplot(forecast(Domestic_Cargo_ATM_autoarimaplot,h=24)) +
  ggtitle("Seasonal ARIMA Plot : Domestic Cargo - Availble Ton Miles Forescast for next two years") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")



# Automatic ARIMA models for seasonal time series S-ARIMA (p,d,q)(P,D,Q)[m]

#  Check that the logged training data of Domestic Cargo Revenue Freight Ton Miles have a stable variance


Domestic_Cargo_FTM_logplot <- autoplot(log(Trainingdata_Domestic_Cargo_FTM)) +
  ggtitle("Log Plot: Domestic Cargo - Revenue Freight Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")

Domestic_Cargo_FTM_logplot

# Fit a seasonal ARIMA model to data with lambda = 0

Domestic_Cargo_FTM_autoarimaplot <- auto.arima(Trainingdata_Domestic_Cargo_FTM, lambda = 0)

Domestic_Cargo_FTM_autoarimaplot

# Checking the summary of the model

summary(Domestic_Cargo_FTM_autoarimaplot)


# Recording the amount of lag-1 differencing and seasonal differencing used
Domestic_Cargo_FTM_d <- 2
Domestic_Cargo_FTM_D <- 0


# Plotting the Forecast for the next 2 years

autoplot(forecast(Domestic_Cargo_FTM_autoarimaplot,h=24)) +
  ggtitle("Seasonal ARIMA Plot : Domestic Cargo - Revenue Freight Ton Miles Forescast for next two years") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")




# Comparing Auto.arima() and ets() for Domestic Cargo ATM


# Auto.ARIMA() model without lambda consideration

Domestic_Cargo_ATM_autoarima <- auto.arima(Trainingdata_Domestic_Cargo_ATM)

Domestic_Cargo_ATM_autoarima

# ETS() model for Domestic Cargo ATM
Domestic_Cargo_ATM_etsplot


# Checking the residuals for both the models

# For ARIMA Model
checkresiduals(Domestic_Cargo_ATM_autoarima)  # Not a white noise data

# For ETS Model
checkresiduals(Domestic_Cargo_ATM_etsplot) # Not White noise data

# Producing the forecast for each model

# For ARIMA Model
Domestic_Cargo_ATM_autoarima_forecast <- forecast(Domestic_Cargo_ATM_autoarima, h = 60)

autoplot(Domestic_Cargo_ATM_autoarima_forecast) +
  ggtitle("Forecast Plot of Seasonal ARIMA model on Training data of Domestic Cargo for Available Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")

# For ETS Model
Domestic_Cargo_ATM_ets_forecast <- forecast(Domestic_Cargo_ATM_etsplot, h = 60)

autoplot(Domestic_Cargo_ATM_ets_forecast) + 
  ggtitle("Forecast Plot of ETS model on Training data of Domestic Cargo for Available Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")

# Using the accuracy () to find the best model  based on RMSE

# For ARIMA model
accuracy(Domestic_Cargo_ATM_autoarima_forecast, Testingdata_Domestic_Cargo_ATM)


# For ETS model
accuracy(Domestic_Cargo_ATM_ets_forecast, Testingdata_Domestic_Cargo_ATM)


# Saving the best model and plotting it

Domestic_Cargo_ATM_autoarima_ets_bestplot <- Domestic_Cargo_ATM_autoarima_forecast

autoplot(Domestic_Cargo_ATM_autoarima_ets_bestplot) +
  ggtitle(" Best Plot : ARIMA model on Training data of Domestic Cargo for Available Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")


# Comparing Auto.arima() and ets() for Domestic Cargo FTM


# Auto.ARIMA() model without lambda consideration

Domestic_Cargo_FTM_autoarima <- auto.arima(Trainingdata_Domestic_Cargo_FTM)

Domestic_Cargo_FTM_autoarima

# ETS() model for Domestic Cargo FTM
Domestic_Cargo_FTM_etsplot


# Checking the residuals for both the models

# For ARIMA Model
checkresiduals(Domestic_Cargo_FTM_autoarima)  # Not a white noise data

# For ETS Model
checkresiduals(Domestic_Cargo_FTM_etsplot) # Not White noise data

# Producing the forecast for each model

# For ARIMA Model
Domestic_Cargo_FTM_autoarima_forecast <- forecast(Domestic_Cargo_FTM_autoarima, h = 60)

autoplot(Domestic_Cargo_FTM_autoarima_forecast) +
  ggtitle("Forecast Plot of Seasonal ARIMA model on Training data of Domestic Cargo for Revenue Freight Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")

# For ETS Model
Domestic_Cargo_FTM_ets_forecast <- forecast(Domestic_Cargo_FTM_etsplot, h = 60)

autoplot(Domestic_Cargo_FTM_ets_forecast) + 
  ggtitle("Forecast Plot of ETS model on Training data of Domestic Cargo for Revenue Freight Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")

# Using the accuracy () to find the best model  based on RMSE

# For ARIMA model
accuracy(Domestic_Cargo_FTM_autoarima_forecast, Testingdata_Domestic_Cargo_FTM)


# For ETS model
accuracy(Domestic_Cargo_FTM_ets_forecast, Testingdata_Domestic_Cargo_FTM)


# Saving the best model and plotting it

Domestic_Cargo_FTM_autoarima_ets_bestplot <- Domestic_Cargo_FTM_autoarima_forecast

autoplot(Domestic_Cargo_FTM_autoarima_ets_bestplot) +
  ggtitle(" Best Plot : ARIMA model on Training data of Domestic Cargo for Revenue Freight Ton Miles Jan 2000 to Aug 2017") +
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")



# TBATS Model

# Plotting the Training data for Available Ton Miles
autoplot(Trainingdata_Domestic_Cargo_ATM) +
  ggtitle("Training Data of Domestic Cargo - Available Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")

# Fitting the TBATS model to the data

Domestic_Cargo_ATM_tbatsmodel <- tbats(Trainingdata_Domestic_Cargo_ATM)

# Forecasting the series for the next 5 years
Domestic_Cargo_ATM_tbatsmodelforecast <- forecast(Domestic_Cargo_ATM_tbatsmodel, h = 60)

# Plotting the forecast
autoplot(Domestic_Cargo_ATM_tbatsmodelforecast) +
  xlab("Year") +
  ylab(" Domestic Cargo ATM -Total volume of Freight carried per Ton Miles")


# Record the Box-Cox parameter and the order of the Fourier terms
Domestic_Cargo_ATM_lambda <- 1

Domestic_Cargo_ATM_lambda

Domestic_Cargo_ATM_K <- 5

Domestic_Cargo_ATM_K

# Plotting the Training data for Revenue Freight Ton Miles
autoplot(Trainingdata_Domestic_Cargo_FTM) +
  ggtitle("Training Data of Domestic Cargo - Revenue Freight Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")

# Fitting the TBATS model to the data

Domestic_Cargo_FTM_tbatsmodel <- tbats(Trainingdata_Domestic_Cargo_FTM)

# Forecasting the series for the next 5 years

Domestic_Cargo_FTM_tbatsmodelforecast <- forecast(Domestic_Cargo_FTM_tbatsmodel, h = 60)

# Plotting the forecast
autoplot(Domestic_Cargo_FTM_tbatsmodelforecast) +
  xlab("Year") +
  ylab(" Domestic Cargo FTM - Total revenue earned from Freight carried per Ton Miles")

# Record the Box-Cox parameter and the order of the Fourier terms
Domestic_Cargo_FTM_lambda <- 1

Domestic_Cargo_FTM_lambda

Domestic_Cargo_FTM_k <- 5

Domestic_Cargo_FTM_k

# Neural Network Autoregression (NNAR) (p,P,size) Model for Available Ton Miles

# Applying the respective parameters of NNAR model which are 
# p: number of non-seasonal lags as inputs.
# P: number of seasonal lags as inputs.
# size: number of hidden nodes in the hidden layer

Domestic_Cargo_ATM_nnarmodel <- nnetar(Domestic_Cargo_ATM, p = 3, P = 1, size = 3)

Domestic_Cargo_ATM_nnarmodel


# Checking the residuals of the model

checkresiduals(Domestic_Cargo_ATM_nnarmodel) #Not a white noise data

# Producing the forecast for the next 5 years . Since it is monthly data we multiply the number of months into the number of respective years we want to forecast the model for

Domestic_Cargo_ATM_nnarmodel_forecast <- forecast(Domestic_Cargo_ATM_nnarmodel, h = 60)


# Producing the plot for Domestic Cargo - Available Ton Miles

Domestic_Cargo_ATM_nnarmodel_forecastplot <- autoplot(Domestic_Cargo_ATM_nnarmodel_forecast) +
  ggtitle("NNAR model : Domestic Cargo - Available Ton Miles - Forecast for next 5 years") +
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")


Domestic_Cargo_ATM_nnarmodel_forecastplot # The results in the following plot where the blue curve shows the 5 year prediction.


# Producting the forecast with Prediction intervals for Domestic Cargo Available Ton Miles.

Domestic_Cargo_ATM_nnarmodel_forecast_predictionintervals <- forecast(Domestic_Cargo_ATM_nnarmodel, PI = TRUE, h = 60)


# Producing the plot for Domestic Cargo - Available Ton Miles with consideration of prediction intervals

Domestic_Cargo_ATM_nnarmodel_forecast_predictionintervalsplot <- autoplot(Domestic_Cargo_ATM_nnarmodel_forecast_predictionintervals) +
  ggtitle("NNAR model with Prediction Intervals: Domestic Cargo - Available Ton Miles - Forecast for next 5 years") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")

Domestic_Cargo_ATM_nnarmodel_forecast_predictionintervalsplot


# Now, changing the parameters of the NNAR model and cross validating this model, this time we 
# change the value of the repeat parameter as well which is nothing but the number of networks to fit with different random starting weights, which are the then averaged when producing the forecasts.
# By default the value of repeat is 20.

Domestic_Cargo_ATM_nnarmodel_newparameters <- nnetar(Trainingdata_Domestic_Cargo_ATM, p = 4, P = 2, size = 3, repeats = 30)

Domestic_Cargo_ATM_nnarmodel_newparameters


# Checking the residuals of the model

checkresiduals(Domestic_Cargo_ATM_nnarmodel_newparameters) #Not a white noise data


# Producing the forecast based on the new parameters for the next 5 years . Since it is monthly data we multiply the number of months into the number of respective years we want to forecast the model for

Domestic_Cargo_ATM_nnarmodel_forecast_newparameters <- forecast(Domestic_Cargo_ATM_nnarmodel_newparameters, h = 60)


# Producing the plot for Domestic Cargo - Available Ton Miles based on the new parameters

Domestic_Cargo_ATM_nnarmodel_forecast_newparameters_plot <- autoplot(Domestic_Cargo_ATM_nnarmodel_forecast_newparameters) +
  ggtitle("NNAR model with New Parameters : Training Data Domestic Cargo - Available Ton Miles - Forecast for next 5 years") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")


Domestic_Cargo_ATM_nnarmodel_forecast_newparameters_plot # The results in the following plot where the blue curve shows the 5 year prediction.


# Producting the forecast based on the new parameters with Prediction intervals for Domestic Cargo Available Ton Miles.

Domestic_Cargo_ATM_nnarmodel_forecast_newparameters_predictionintervals <- forecast(Domestic_Cargo_ATM_nnarmodel_newparameters, PI = TRUE, h = 60)


# Producing the plot for Domestic Cargo - Available Ton Miles with consideration of prediction intervals

Domestic_Cargo_ATM_nnarmodel_forecast_newparameters_predictionintervals_plot <- autoplot(Domestic_Cargo_ATM_nnarmodel_forecast_newparameters_predictionintervals) +
  ggtitle("NNAR model for New Parameters with Prediction Intervals: Training Data Domestic Cargo - Available Ton Miles - Forecast for next 5 years") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")

Domestic_Cargo_ATM_nnarmodel_forecast_newparameters_predictionintervals_plot


# Producing the forecast Plot with consideration of the Testing Data of Domestic Cargo ATM

autoplot(Domestic_Cargo_ATM_nnarmodel_forecast_newparameters) +
  autolayer(Testingdata_Domestic_Cargo_ATM, series = "Testing data of Domestic Cargo ATM") +
  ggtitle("NNAR model Plot of Training Data Domestic Cargo with consideration of the Testing Data of Domestic Cargo - Available Ton Miles") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")


# Producing the forecast Plot with consideration of Prediction Intervals and with consideration of the Testing Data of Domestic Cargo ATM

autoplot(Domestic_Cargo_ATM_nnarmodel_forecast_newparameters_predictionintervals) +
  autolayer(Testingdata_Domestic_Cargo_ATM, series = "Testing data of Domestic Cargo ATM") +
  ggtitle("NNAR model of Training Data Domestic Cargo with Prediction Intervals with consideration of the Testing Data of Domestic Cargo - Available Ton Miles") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")


# Computing the  prediction intervals using simulation 
# where future sample paths are generated using bootstrapped residuals.
# Simulation of 10 possible future sample 
# For NNAR model - Available Ton Miles


# Simulating the next 5 years of monthly data of Domestic cargo ATM using our neural network model created.

Domestic_Cargo_ATM_nn = nnetar(Domestic_Cargo_ATM, p = 4, P = 2, size = 3)
Domestic_Cargo_ATM_simulation <- ts(matrix(0, nrow=60L, ncol=10L),start=end(Domestic_Cargo_ATM)[1L],frequency=12)
for(i in seq(10)){
  Domestic_Cargo_ATM_simulation[,i]=simulate(Domestic_Cargo_ATM_nn,nsim=60L)
  }
autoplot(Domestic_Cargo_ATM)+autolayer(Domestic_Cargo_ATM_simulation) + 
  ylab("Total volume of Freight carried per Ton Miles") + 
  xlab("Year") + 
  ggtitle("NNAR model : Domestic Cargo - Available Ton Miles - Forecast for next 5 years with Simulation")


# Forecasting the Simulation Model by setting the Prediction Interval and for the period of next 5 years

Domestic_Cargo_ATM_simulation_forecast <- forecast(Domestic_Cargo_ATM_nn, PI = TRUE, h = 60)

Domestic_Cargo_ATM_simulation_forecast
# Plotting the simulation of the Forecasting model by setting the Prediction Interval

autoplot(Domestic_Cargo_ATM_simulation_forecast) +
  ggtitle("Simulation forecast of NNAR model with by setting the Prediction Interval : Domestic Cargo - Available Ton Miles - Forecast for next 5 years") +
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")



# Comparing the accuracy of NNAR with Holt's Winter, ETS, ARIMA and TBATS model based on RMSE

accuracy(Domestic_Cargo_ATM_nnarmodel_forecast_newparameters, Testingdata_Domestic_Cargo_ATM)

accuracy(Domestic_Cargo_ATM_holtwinterplot, Testingdata_Domestic_Cargo_ATM)

accuracy(Domestic_Cargo_ATM_ets_forecast, Testingdata_Domestic_Cargo_ATM)

accuracy(Domestic_Cargo_ATM_autoarima_forecast, Testingdata_Domestic_Cargo_ATM)

accuracy(Domestic_Cargo_ATM_tbatsmodelforecast , Testingdata_Domestic_Cargo_ATM)

# Saving the Best Accuracy model

Domestic_Cargo_ATM_nnar_holtwinter_ets_arima  <- Domestic_Cargo_ATM_autoarima_forecast

# Plotting the Best Accuracy model

autoplot(Domestic_Cargo_ATM_nnar_holtwinter_ets_arima) +
  ggtitle(" Best Plot : ARIMA model on Training data of Domestic Cargo for Available Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year")
  ylab("Total volume of Freight carried per Ton Miles")


# Neural Network Autoregression (NNAR) (p,P,size) Model for Revenue Freight Ton Miles

# Applying the respective parameters of NNAR model which are 
# p: number of non-seasonal lags as inputs.
# P: number of seasonal lags as inputs.
# size: number of hidden nodes in the hidden layer

Domestic_Cargo_FTM_nnarmodel <- nnetar(Domestic_Cargo_FTM, p = 3, P = 1, size = 3)

Domestic_Cargo_FTM_nnarmodel


# Checking the residuals of the model

checkresiduals(Domestic_Cargo_FTM_nnarmodel) #Not a white noise data

# Producing the forecast for the next 5 years . Since it is monthly data we multiply the number of months into the number of respective years we want to forecast the model for

Domestic_Cargo_FTM_nnarmodel_forecast <- forecast(Domestic_Cargo_FTM_nnarmodel, h = 60)


# Producing the plot for Domestic Cargo - Available Ton Miles

Domestic_Cargo_FTM_nnarmodel_forecastplot <- autoplot(Domestic_Cargo_FTM_nnarmodel_forecast) +
  ggtitle("NNAR model : Domestic Cargo - Revenue Freight Ton Miles - Forecast for next 5 years") +
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")


Domestic_Cargo_FTM_nnarmodel_forecastplot # The results in the following plot where the blue curve shows the 5 year prediction.


# Producting the forecast with Prediction intervals for Domestic Cargo Available Ton Miles.

Domestic_Cargo_FTM_nnarmodel_forecast_predictionintervals <- forecast(Domestic_Cargo_FTM_nnarmodel, PI = TRUE, h = 60)


# Producing the plot for Domestic Cargo - Freight Ton Miles with consideration of prediction intervals

Domestic_Cargo_FTM_nnarmodel_forecast_predictionintervalsplot <- autoplot(Domestic_Cargo_FTM_nnarmodel_forecast_predictionintervals) +
  ggtitle("NNAR model with Prediction Intervals: Domestic Cargo - Revenue Freight Ton Miles - Forecast for next 5 years") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")

Domestic_Cargo_FTM_nnarmodel_forecast_predictionintervalsplot


# Now, changing the parameters of the NNAR model and cross validating this model, this time we 
# change the value of the repeat parameter as well which is nothing but the number of networks to fit with different random starting weights, which are the then averaged when producing the forecasts.
# By default the value of repeat is 20.

Domestic_Cargo_FTM_nnarmodel_newparameters <- nnetar(Trainingdata_Domestic_Cargo_FTM, p = 4, P = 2, size = 3, repeats = 30)

Domestic_Cargo_FTM_nnarmodel_newparameters


# Checking the residuals of the model

checkresiduals(Domestic_Cargo_FTM_nnarmodel_newparameters) #Not a white noise data


# Producing the forecast based on the new parameters for the next 5 years . Since it is monthly data we multiply the number of months into the number of respective years we want to forecast the model for

Domestic_Cargo_FTM_nnarmodel_forecast_newparameters <- forecast(Domestic_Cargo_FTM_nnarmodel_newparameters, h = 60)


# Producing the plot for Domestic Cargo - Available Ton Miles based on the new parameters

Domestic_Cargo_FTM_nnarmodel_forecast_newparameters_plot <- autoplot(Domestic_Cargo_FTM_nnarmodel_forecast_newparameters) +
  ggtitle("NNAR model with New Parameters : Training Data Domestic Cargo - Revenue Freight Ton Miles - Forecast for next 5 years") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")


Domestic_Cargo_FTM_nnarmodel_forecast_newparameters_plot # The results in the following plot where the blue curve shows the 5 year prediction.


# Producting the forecast based on the new parameters with Prediction intervals for Domestic Cargo Freight Ton Miles.

Domestic_Cargo_FTM_nnarmodel_forecast_newparameters_predictionintervals <- forecast(Domestic_Cargo_FTM_nnarmodel_newparameters, PI = TRUE, h = 60)


# Producing the plot for Domestic Cargo - Freight Ton Miles with consideration of prediction intervals

Domestic_Cargo_FTM_nnarmodel_forecast_newparameters_predictionintervals_plot <- autoplot(Domestic_Cargo_FTM_nnarmodel_forecast_newparameters_predictionintervals) +
  ggtitle("NNAR model for New Parameters with Prediction Intervals: Training Data Domestic Cargo - Revenue Freight Ton Miles - Forecast for next 5 years") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")

Domestic_Cargo_FTM_nnarmodel_forecast_newparameters_predictionintervals_plot


# Producing the forecast Plot with consideration of the Testing Data of Domestic Cargo FTM

autoplot(Domestic_Cargo_FTM_nnarmodel_forecast_newparameters) +
  autolayer(Testingdata_Domestic_Cargo_FTM, series = "Testing data of Domestic Cargo FTM") +
  ggtitle("NNAR model Plot of Training Data Domestic Cargo with consideration of the Testing Data of Domestic Cargo - Revenue Freight Ton Miles") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")


# Producing the forecast Plot with consideration of Prediction Intervals and with consideration of the Testing Data of Domestic Cargo FTM

autoplot(Domestic_Cargo_FTM_nnarmodel_forecast_newparameters_predictionintervals) +
  autolayer(Testingdata_Domestic_Cargo_FTM, series = "Testing data of Domestic Cargo FTM") +
  ggtitle("NNAR model of Training Data Domestic Cargo with Prediction Intervals with consideration of the Testing Data of Domestic Cargo - Revenue Freight Ton Miles") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")


# Computing the  prediction intervals using simulation 
# where future sample paths are generated using bootstrapped residuals.
# Simulation of 10 possible future sample 
# For NNAR model - Freight Ton Miles


# Simulating the next 5 years of monthly data of Domestic cargo ATM using our neural network model created.

Domestic_Cargo_FTM_nn = nnetar(Domestic_Cargo_FTM, p = 4, P = 2, size = 3)
Domestic_Cargo_FTM_simulation <- ts(matrix(0, nrow=60L, ncol=10L),start=end(Domestic_Cargo_FTM)[1L],frequency=12)
for(i in seq(10)){
  Domestic_Cargo_FTM_simulation[,i]=simulate(Domestic_Cargo_FTM_nn,nsim=60L)
}
autoplot(Domestic_Cargo_FTM)+autolayer(Domestic_Cargo_FTM_simulation) + 
  ylab("Total revenue earned from Freight carried per Ton Miles") + 
  xlab("Year") + 
  ggtitle("NNAR model : Domestic Cargo - Revenue Freight Ton Miles - Forecast for next 5 years with Simulation")


# Forecasting the Simulation Model by setting the Prediction Interval and for the period of next 5 years

Domestic_Cargo_FTM_simulation_forecast <- forecast(Domestic_Cargo_FTM_nn, PI = TRUE, h = 60)

Domestic_Cargo_FTM_simulation_forecast
# Plotting the simulation of the Forecasting model by setting the Prediction Interval

autoplot(Domestic_Cargo_FTM_simulation_forecast) +
  ggtitle("Simulation forecast of NNAR model with by setting the Prediction Interval : Domestic Cargo - Revenue Freight Ton Miles - Forecast for next 5 years") +
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")



# Comparing the accuracy of NNAR with Holt's Winter, ETS, ARIMA and TBATS model based on RMSE

accuracy(Domestic_Cargo_FTM_nnarmodel_forecast_newparameters, Testingdata_Domestic_Cargo_FTM)

accuracy(Domestic_Cargo_FTM_holtwinterplot, Testingdata_Domestic_Cargo_FTM)

accuracy(Domestic_Cargo_FTM_ets_forecast, Testingdata_Domestic_Cargo_FTM)

accuracy(Domestic_Cargo_FTM_autoarima_forecast, Testingdata_Domestic_Cargo_FTM)

accuracy(Domestic_Cargo_FTM_tbatsmodelforecast , Testingdata_Domestic_Cargo_FTM)

# Saving the Best Accuracy model

Domestic_Cargo_FTM_nnar_holtwinter_ets_arima  <- Domestic_Cargo_FTM_holtwinterplot

# Plotting the Best Accuracy model

autoplot(Domestic_Cargo_FTM_nnar_holtwinter_ets_arima) +
  ggtitle(" Best Plot : Holt Winter model on Training data of Domestic Cargo for Revenue Freight Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")



# Dynamic Harmonic Regression for Domestic Cargo Available Ton Miles

# Plotting the Training data for Available Ton Miles
autoplot(Trainingdata_Domestic_Cargo_ATM) +
  ggtitle("Training Data of Domestic Cargo - Available Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")

# Four term (k) for Domestic cargo Avilable Ton Miles as per the TBATS model
Domestic_Cargo_ATM_K

# Setting up the Harmonic regressors of order Fourier Term (k)

Domestic_Cargo_ATM_harmonics <- fourier(Trainingdata_Domestic_Cargo_ATM, K = Domestic_Cargo_ATM_K)

Domestic_Cargo_ATM_harmonics

# Fitting the Dynamic Harmonic Regression model with ARIMA errors

Domestic_Cargo_ATM_DynamicHarmonicRegression <- auto.arima(Trainingdata_Domestic_Cargo_ATM, xreg = Domestic_Cargo_ATM_harmonics, seasonal = FALSE)

Domestic_Cargo_ATM_DynamicHarmonicRegression


# Forecasting For the next 5 years

Domestic_Cargo_ATM_newharmonics <- fourier(Trainingdata_Domestic_Cargo_ATM, K = Domestic_Cargo_ATM_K, h = 60)

Domestic_Cargo_ATM_DynamicHarmonicRegression_forecast <- forecast(Domestic_Cargo_ATM_DynamicHarmonicRegression, xreg = Domestic_Cargo_ATM_newharmonics)


# Plotting the Forcast of the Dynamic Regression Forecasting Model

autoplot(Domestic_Cargo_ATM_DynamicHarmonicRegression_forecast) +
  ggtitle("Dynamic Harmonic Regression Model: Domestic Cargo - Available Ton Miles") +
  ylab("Total volume of Freight carried per Ton Miles") +
  xlab("Year")


# Comparing the accuaracy of the model with Neural Network Auto Regression (NNAR) model for Domestic Cargo - Available Ton Miles

accuracy(Domestic_Cargo_ATM_nnarmodel_forecast_newparameters, Testingdata_Domestic_Cargo_ATM)

accuracy(Domestic_Cargo_ATM_DynamicHarmonicRegression_forecast, Testingdata_Domestic_Cargo_ATM)


# Saving the best accuracy of the model

Domestic_Cargo_ATM_nnar_dynamicharmonicregression_best <- Domestic_Cargo_ATM_DynamicHarmonicRegression_forecast

# Plotting the Best Accuracy model

autoplot(Domestic_Cargo_ATM_nnar_dynamicharmonicregression_best) +
  ggtitle(" Best Plot: Dynamic Harmonic Regression Model: Domestic Cargo - Available Ton Miles") +
  ylab("Total volume of Freight carried per Ton Miles") +
  xlab("Year")




# Dynamic Harmonic Regression for Domestic Cargo Revenue Freight Ton Miles

# Plotting the Training data for Freight Ton Miles
autoplot(Trainingdata_Domestic_Cargo_FTM) +
  ggtitle("Training Data of Domestic Cargo - Revenue Freight Ton Miles Jan 2000 to Aug 2017") +
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")


# Four term (k) for Domestic cargo Freight Ton Miles as per the TBATS model
Domestic_Cargo_FTM_k

# Setting up the Harmonic regressors of order Fourier Term (k)

Domestic_Cargo_FTM_harmonics <- fourier(Trainingdata_Domestic_Cargo_FTM, K = Domestic_Cargo_FTM_k)

Domestic_Cargo_FTM_harmonics

# Fitting the Dynamic Harmonic Regression model with ARIMA errors

Domestic_Cargo_FTM_DynamicHarmonicRegression <- auto.arima(Trainingdata_Domestic_Cargo_FTM, xreg = Domestic_Cargo_FTM_harmonics, seasonal = FALSE)

Domestic_Cargo_FTM_DynamicHarmonicRegression


# Forecasting For the next 5 years

Domestic_Cargo_FTM_newharmonics <- fourier(Trainingdata_Domestic_Cargo_FTM, K = Domestic_Cargo_FTM_k, h = 60)

Domestic_Cargo_FTM_DynamicHarmonicRegression_forecast <- forecast(Domestic_Cargo_FTM_DynamicHarmonicRegression, xreg = Domestic_Cargo_FTM_newharmonics)


# Plotting the Forcast of the Dynamic Regression Forecasting Model

autoplot(Domestic_Cargo_FTM_DynamicHarmonicRegression_forecast) +
  ggtitle("Dynamic Harmonic Regression Model: Domestic Cargo - Revenue Freight Ton Miles") +
  ylab("Total revenue earned from Freight carried per Ton Miles") +
  xlab("Year")


# Comparing the accuaracy of the model with Neural Network Auto Regression (NNAR) model for Domestic Cargo - Revenue Freight Ton Miles

accuracy(Domestic_Cargo_FTM_nnarmodel_forecast_newparameters, Testingdata_Domestic_Cargo_FTM)

accuracy(Domestic_Cargo_FTM_DynamicHarmonicRegression_forecast, Testingdata_Domestic_Cargo_FTM)


# Saving the best accuracy of the model

Domestic_Cargo_FTM_nnar_dynamicharmonicregression_best <- Domestic_Cargo_FTM_DynamicHarmonicRegression_forecast

# Plotting the Best Accuracy model

autoplot(Domestic_Cargo_FTM_nnar_dynamicharmonicregression_best) +
  ggtitle(" Best Plot: Dynamic Harmonic Regression Model: Domestic Cargo - Revenue Freight Ton Miles") +
  ylab("Total revenue earned from Freight carried per Ton Miles") +
  xlab("Year")



# Comparing all the forecasting model for Available Ton Miles

accuracy(Domestic_Cargo_ATM_naiveplot, Testingdata_Domestic_Cargo_ATM)

accuracy(Domestic_Cargo_ATM_snaiveplot, Testingdata_Domestic_Cargo_ATM)

accuracy(Domestic_Cargo_ATM_meanplot, Testingdata_Domestic_Cargo_ATM)

accuracy(Domestic_Cargo_ATM_sesplot, Testingdata_Domestic_Cargo_ATM)

accuracy(Domestic_Cargo_ATM_holtplot, Testingdata_Domestic_Cargo_ATM)

accuracy(Domestic_Cargo_ATM_holtwinterplot, Testingdata_Domestic_Cargo_ATM)

accuracy(Domestic_Cargo_ATM_autoarima_forecast, Testingdata_Domestic_Cargo_ATM)

accuracy(Domestic_Cargo_ATM_ets_forecast, Testingdata_Domestic_Cargo_ATM)

accuracy(Domestic_Cargo_ATM_tbatsmodelforecast , Testingdata_Domestic_Cargo_ATM)

accuracy(Domestic_Cargo_ATM_nnarmodel_forecast_newparameters, Testingdata_Domestic_Cargo_ATM)

accuracy(Domestic_Cargo_ATM_DynamicHarmonicRegression_forecast, Testingdata_Domestic_Cargo_ATM)

# Saving the best accuracy plot

Domestic_Cargo_ATM_bestmodel <- Domestic_Cargo_ATM_autoarima_forecast

# Plotting the Best accuracy Model

autoplot(Domestic_Cargo_ATM_bestmodel) +
  ggtitle("Best Plot- ARIMA Model: Domestic Cargo - Available Ton Miles") +
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")




# Comparing all the forecasting model for Freight Ton Miles

accuracy(Domestic_Cargo_FTM_naiveplot, Testingdata_Domestic_Cargo_FTM)

accuracy(Domestic_Cargo_FTM_snaiveplot, Testingdata_Domestic_Cargo_FTM)

accuracy(Domestic_Cargo_FTM_meanplot, Testingdata_Domestic_Cargo_FTM)

accuracy(Domestic_Cargo_FTM_sesplot, Testingdata_Domestic_Cargo_FTM)

accuracy(Domestic_Cargo_FTM_holtplot, Testingdata_Domestic_Cargo_FTM)

accuracy(Domestic_Cargo_FTM_holtwinterplot, Testingdata_Domestic_Cargo_FTM)

accuracy(Domestic_Cargo_FTM_autoarima_forecast, Testingdata_Domestic_Cargo_FTM)

accuracy(Domestic_Cargo_FTM_ets_forecast, Testingdata_Domestic_Cargo_FTM)

accuracy(Domestic_Cargo_FTM_tbatsmodelforecast , Testingdata_Domestic_Cargo_FTM)

accuracy(Domestic_Cargo_FTM_nnarmodel_forecast_newparameters, Testingdata_Domestic_Cargo_FTM)

accuracy(Domestic_Cargo_FTM_DynamicHarmonicRegression_forecast, Testingdata_Domestic_Cargo_FTM)


# Saving the best accuracy plot

Domestic_Cargo_FTM_bestmodel <- Domestic_Cargo_FTM_holtwinterplot

# Plotting the Best accuracy Model

autoplot(Domestic_Cargo_FTM_bestmodel) +
  ggtitle("Best Plot- Holt Winter Model: Domestic Cargo - Revenue Freight Ton Miles") +
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")

