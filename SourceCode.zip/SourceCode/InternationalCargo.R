
# Applying the Time Series Forecasting models and perfoming analysis on International Cargo for both of its parameters 
# which are ATM (Available Ton Miles) and Revenue FTM (Freight Ton Miles)


# Applying "gglagplot" against lagged versions of themselves. 
# Which helps visualising 'auto-dependence' even when auto-correlations vanish.

# Available Ton Miles
International_Cargo_ATM_lagplot <- gglagplot(International_Cargo_ATM) + 
  ggtitle("International Cargo Lag Plot - Available Ton Miles (January 2000 - February 2020)")

International_Cargo_ATM_lagplot

# Freight Ton Miles
International_Cargo_FTM_lagplot <- gglagplot(International_Cargo_FTM) + 
  ggtitle("International Cargo Lag Plot - Freight Ton Miles (January 2000 - February 2020)")

International_Cargo_FTM_lagplot

# International Records
International_Cargo_lagplot <- gglagplot(Data_International_Cargo_Plot) +
  ggtitle("International Cargo Records (January 2000 - February 2020)") + 
International_Cargo_lagplot


# Applying the test of Autocorrelation 
# Applying the correlations associated with the lag plots form 
#what is called the autocorrelation function (ACF).

# Available Ton Miles
International_Cargo_ATM_acfplot<- ggAcf(International_ATM_Diff) + 
  ggtitle("International Cargo  ACF Plot - Available Ton Miles (January 2000 - February 2020)")


International_Cargo_ATM_acfplot

# Freight Ton Miles
International_Cargo_FTM_acfplot <- ggAcf(International_FTM_Diff) + 
  ggtitle("International Cargo  ACF Plot - Freight Ton Miles (January 2000 - February 2020)")

International_Cargo_FTM_acfplot

# International Records
International_Cargo_acfplot <- ggAcf(Diff_International_Cargo) +
  ggtitle("International Cargo  ACF Plot (January 2000 - February 2020)")

International_Cargo_acfplot


# Note: The Box test can be applied only to the univariate time series analysis.

# Available Ton Miles
International_Cargo_ATM_Boxtest <- Box.test(International_ATM_Diff, lag = 16, type = "Ljung")

International_Cargo_ATM_Boxtest

# Freight Ton Miles
International_Cargo_FTM_Boxtest <- Box.test(International_FTM_Diff, lag = 16, type = "Ljung")

International_Cargo_FTM_Boxtest

# Splitting the Dataset into Training and Testing Data


# Availabe Ton Miles
split_International_Cargo_ATM <- ts_split(International_Cargo_ATM, sample.out = 30)

Trainingdata_International_Cargo_ATM  <- split_International_Cargo_ATM$train
Testingdata_International_Cargo_ATM <- split_International_Cargo_ATM$test

# Checking the length
length(International_Cargo_ATM)
length(Trainingdata_International_Cargo_ATM)
length(Testingdata_International_Cargo_ATM)


# In order to check whether the data frame is of time series object we make use of the is.ts() function
# It returns a boolean results in which True indicate a time series object and False indicates a non time series object

#  International Cargo Available Ton Miles
is.ts(International_Cargo_ATM) # Time Series Data object

#  Training Data of International Cargo Available Ton Miles
is.ts(Trainingdata_International_Cargo_ATM) # Time Series Data object

# Testing Data of International Cargo Available Ton Miles
is.ts(Testingdata_International_Cargo_ATM) # Time Series Data object



# Freight Ton Miles
split_International_Cargo_FTM <- ts_split(International_Cargo_FTM, sample.out = 30)

Trainingdata_International_Cargo_FTM  <- split_International_Cargo_FTM$train
Testingdata_International_Cargo_FTM <- split_International_Cargo_FTM$test

# Checking the length
length(International_Cargo_FTM)
length(Trainingdata_International_Cargo_FTM)
length(Testingdata_International_Cargo_FTM)


# In order to check whether the data frame is of time series object we make use of the is.ts() function
# It returns a boolean results in which True indicate a time series object and False indicates a non time series object

# International Cargo Available Ton Miles
is.ts(International_Cargo_FTM) # Time Series Data object

# Training Data of International Cargo Available Ton Miles
is.ts(Trainingdata_International_Cargo_FTM) # Time Series Data object

# Testing Data of International Cargo Available Ton Miles
is.ts(Testingdata_International_Cargo_FTM) # Time Series Data object


# International Cargo Records
split_International_Cargo <- ts_split(Data_International_Cargo_Plot, sample.out = 30)

Trainingdata_International_Cargo  <- split_International_Cargo$train
Testingdata_International_Cargo <- split_International_Cargo$test

# Checking the length
length(Data_International_Cargo_Plot)
length(Trainingdata_International_Cargo)
length(Testingdata_International_Cargo)


# In order to check whether the data frame is of time series object we make use of the is.ts() function
# It returns a boolean results in which True indicate a time series object and False indicates a non time series object

# International Cargo Records
is.ts(Data_International_Cargo_Plot) # Time Series Data object

# Training Data of International Cargo Available Ton Miles
is.ts(Trainingdata_International_Cargo) # Time Series Data object

# Testing Data of International Cargo Available Ton Miles
is.ts(Testingdata_International_Cargo) # Time Series Data object


# Applying the Naive Method
# Notes: Naive Method simply uses the most recent observation as the forecast for future observation.
# Note: The darker region is an 80% interval, and the lighter region is a 95% interval
# 80% forecast intervals should contain 80% of future observations.
# 95% forecast intervals should contain 95% of future observations.
# The default plot for forecast in R looks like this with both 80% and 95% region shown.
# We can check the residuals only for univariate time series analysis

# Availabe Ton Miles - Forecasting for next 5 years
International_Cargo_ATM_naiveplot <- naive(Trainingdata_International_Cargo_ATM, h = 60)

# Creating the plot
autoplot(International_Cargo_ATM_naiveplot) + 
  ggtitle("Naive Plot: International Cargo - Available Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")

#  Checking the Summary
summary(International_Cargo_ATM_naiveplot)

# Checking the residuals
checkresiduals(International_Cargo_ATM_naiveplot)  # Not a white noise data


# Freight Ton Miles - Forecasing for the next 5 years
International_Cargo_FTM_naiveplot <- naive(Trainingdata_International_Cargo_FTM, h = 60)

# Creating the Plot
autoplot(International_Cargo_FTM_naiveplot) + 
  ggtitle("Naive Plot: International Cargo - Revenue Freight Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")

# Checking the Summary
summary(International_Cargo_FTM_naiveplot)

# Checking the residuals
checkresiduals(International_Cargo_FTM_naiveplot)  # Not a white noise data


# International Cargo Records - Forecasting for the next 5 years
International_Cargo_naiveplot <- naive(Trainingdata_International_Cargo, h = 60)

# Creating the Plot
autoplot(International_Cargo_naiveplot) + 
  ggtitle("Naive Plot: International Cargo Records (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total Volume and Revenue earned by International Cargo")

# Checking the summary
summary(International_Cargo_naiveplot)



# Applying the Seasonal naive Method
# Note: we set each forecast to be equal to the last observed value from the same season of the year (e.g., the same month of the previous year).

# Available Ton Miles - Forecasting for the next 5 years
International_Cargo_ATM_snaiveplot <- snaive(Trainingdata_International_Cargo_ATM, h = 60)

# Creating the Plot
autoplot(International_Cargo_ATM_snaiveplot) + 
  ggtitle("Seasonal Naive Plot: International Cargo - Available Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles") 

# Checking the Summary
summary(International_Cargo_ATM_snaiveplot)

# Checking the residuals
checkresiduals(International_Cargo_ATM_snaiveplot) # Not a white noise data


# Freight Ton Miles - Forecasting for next 5 years
International_Cargo_FTM_snaiveplot <- snaive(Trainingdata_International_Cargo_FTM, h = 60)


# Creating the Plot
autoplot(International_Cargo_FTM_snaiveplot) + 
  ggtitle("Seasonal Naive Plot: International Cargo - Revenue Freight Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")


# Checking the Summary
summary(International_Cargo_FTM_snaiveplot)


# Checking the residuals
checkresiduals(International_Cargo_FTM_snaiveplot)  #Not a white noise data


# International Cargo Records - Forecasting for the next 5 years
International_Cargo_snaiveplot <- snaive(Trainingdata_International_Cargo, h = 60)

# Creating the plot
autoplot(International_Cargo_snaiveplot) + 
  ggtitle("Seasonal Naive Plot: International Cargo Records (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total Volume and Revenue earned by International Cargo")

# Checking the Summary
summary(International_Cargo_snaiveplot)


# Applying the Mean Plot
# Note: the forecasts of all future values are equal to the average (or "mean") of the historical data.


# Available Ton Miles - For the next 5 years
International_Cargo_ATM_meanplot <- meanf(Trainingdata_International_Cargo_ATM, h = 60)


# Creating the Plot
autoplot(International_Cargo_ATM_meanplot) + 
  ggtitle("Mean Plot: International Cargo - Available Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")


# Checking the Summary
summary(International_Cargo_ATM_meanplot)

# Checking the residuals
checkresiduals(International_Cargo_ATM_meanplot) # Not a white noise data


# Freight Ton Miles - For the next 5 years
International_Cargo_FTM_meanplot <- meanf(Trainingdata_International_Cargo_FTM, h = 60)

# Creating the Plot
autoplot(International_Cargo_FTM_meanplot) + 
  ggtitle("Mean Plot: International Cargo - Revenue Freight Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")


# Checking the Summary
summary(International_Cargo_FTM_meanplot)

# Checking the residuals
checkresiduals(International_Cargo_FTM_meanplot)  # Not a white noise data


# From the Naive Method and Snaive Method we see that there is no white noise in the data
# Since p < 0.05


# Comparing Accuracy of Naive, SNaive and Mean method by checking the RMSE

# Available Ton Miles
accuracy(International_Cargo_ATM_naiveplot, Testingdata_International_Cargo_ATM)

accuracy(International_Cargo_ATM_snaiveplot, Testingdata_International_Cargo_ATM)

accuracy(International_Cargo_ATM_meanplot, Testingdata_International_Cargo_ATM)


# Saving the best forecast method for Available Ton Miles 

International_Cargo_ATM_naive_snaive_mean_best <- International_Cargo_ATM_naiveplot

International_Cargo_ATM_naive_snaive_mean_best


# Plotting the best forecast model

autoplot(International_Cargo_ATM_naiveplot) + 
  ggtitle("Best Plot Naive Plot: International Cargo - Available Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")


# Freight Ton Miles
accuracy(International_Cargo_FTM_naiveplot, Testingdata_International_Cargo_FTM)

accuracy(International_Cargo_FTM_snaiveplot, Testingdata_International_Cargo_FTM)

accuracy(International_Cargo_FTM_meanplot, Testingdata_International_Cargo_FTM)


# Saving the best forecast method for Freight Ton Miles

International_Cargo_FTM_naive_snaive_mean_best <- International_Cargo_FTM_naiveplot

International_Cargo_FTM_naive_snaive_mean_best

# Plotting the best forecast model


autoplot(International_Cargo_FTM_naiveplot) + 
  ggtitle("Best Plot Naive Plot: International Cargo - Revenue Freight Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles") 



# Applying the Time Series Cross Validation for Available Ton Miles

# Compute cross-validated errors for up to 10 steps ahead
International_Cargo_ATM_error <- tsCV(Trainingdata_International_Cargo_ATM, forecastfunction = naive, h = 10)
International_Cargo_ATM_error

# Compute the MSE values and remove missing values
International_Cargo_ATM_mse <- colMeans(International_Cargo_ATM_error^2, na.rm = TRUE)
International_Cargo_ATM_mse

# Plot the MSE values against the forecast horizon
International_Cargo_ATM_TimeSeriesCrossValidationPlot <- data.frame(h = 1:10, MSE = International_Cargo_ATM_mse) %>%
  ggplot(aes(x = h, y = MSE)) +
  geom_point() + 
  ggtitle("Time Series Cross Validation Plot : International Cargo Available Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")

International_Cargo_ATM_TimeSeriesCrossValidationPlot

# Applying the Time Series Cross Validation for Freight Ton Miles

# Compute cross-validated errors for up to 10 steps ahead
International_Cargo_FTM_error <- tsCV(Trainingdata_International_Cargo_FTM, forecastfunction = naive, h = 10)
International_Cargo_FTM_error

# Compute the MSE values and remove missing values
International_Cargo_FTM_mse <- colMeans(International_Cargo_FTM_error^2, na.rm = TRUE)
International_Cargo_FTM_mse

# Plot the MSE values against the forecast horizon
International_Cargo_FTM_TimeSeriesCrossValidationPlot <- data.frame(h = 1:10, MSE = International_Cargo_FTM_mse) %>%
  ggplot(aes(x = h, y = MSE)) + 
  geom_point() + 
  ggtitle("Time Series Cross Validation Plot : International Cargo Revenue Freight Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")

International_Cargo_FTM_TimeSeriesCrossValidationPlot


# Applying Simple Exponential Smoothing Method to Availabe Ton Miles For Forecasting for the next 5 years

International_Cargo_ATM_sesplot <- ses(Trainingdata_International_Cargo_ATM, h = 60)

International_Cargo_ATM_sesplot

# Checking the summary of the model
summary(International_Cargo_ATM_sesplot)

# Creating the Plot

autoplot(International_Cargo_ATM_sesplot) +
  ggtitle("Simple Exponential Smoothing Plot: International Cargo Available Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")


# Add the one-step forecasts for the training data to the plot
autoplot(International_Cargo_ATM_sesplot) + 
  autolayer(fitted(International_Cargo_ATM_sesplot)) +
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")


# Applying Simple Exponential Smoothing Method to Freight Ton Miles For Forecasting for the next 5 years

International_Cargo_FTM_sesplot <- ses(Trainingdata_International_Cargo_FTM, h = 60)

International_Cargo_FTM_sesplot

# Checking the summary of the model
summary(International_Cargo_FTM_sesplot)

# Creating the Plot

autoplot(International_Cargo_FTM_sesplot) +
  ggtitle("Simple Exponential Smoothing Plot: International Cargo Revenue Freight Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")


# Add the one-step forecasts for the training data to the plot
autoplot(International_Cargo_FTM_sesplot) + 
  autolayer(fitted(International_Cargo_FTM_sesplot)) +
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")


# Compare Simple Exponetial Smoothing (SES) and Naive Forecast Accuracy
# Note: Pick a measure in the output, such as RMSE or MAE, 
#to evaluate the forecast(s); a smaller error indicates higher accuracy.

# Available Ton Miles
accuracy(International_Cargo_ATM_sesplot, Testingdata_International_Cargo_ATM)
accuracy(International_Cargo_ATM_naiveplot, Testingdata_International_Cargo_ATM)


# Saving the best forecast method for Available Ton Miles

International_Cargo_ATM_ses_naive_best <- International_Cargo_ATM_naiveplot

International_Cargo_ATM_ses_naive_best


# Ploting the best forecasting method for Available Ton Miles
autoplot(International_Cargo_ATM_ses_naive_best) + 
  ggtitle("Naive Plot : International Cargo - Available Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")



# Freight Ton Miles

accuracy(International_Cargo_FTM_sesplot, Testingdata_International_Cargo_FTM)
accuracy(International_Cargo_FTM_naiveplot, Testingdata_International_Cargo_FTM)

# Saving the best forecast method for Freight Ton Miles

International_Cargo_FTM_ses_naive_best <- International_Cargo_FTM_naiveplot

International_Cargo_FTM_ses_naive_best

# Ploting the best forecasting method for Freight Ton Miles
autoplot(International_Cargo_FTM_ses_naive_best) +
  ggtitle("Naive Plot: International Cargo Revenue Freight Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")



# Exponential Smoothing methods with trend


# Applying the Holt's Linear trend Method for Available Ton Miles Data for next five years

International_Cargo_ATM_holtplot <- holt(Trainingdata_International_Cargo_ATM, h = 60)
International_Cargo_ATM_holtplot

# Checking the summary of the model

summary(International_Cargo_ATM_holtplot)

# Checking the residuals
checkresiduals(International_Cargo_ATM_holtplot)  # Not a white noise data


# Ploting the forecast model

autoplot(International_Cargo_ATM_holtplot) +
  ggtitle("Holt Linear Trend : International Cargo - Available Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")



# Applying the Holt's Linear trend Method for Freight Ton Miles Data For Forecasting for the next 5 years

International_Cargo_FTM_holtplot <- holt(Trainingdata_International_Cargo_FTM, h = 60)
International_Cargo_FTM_holtplot

# Checking the summary of the model

summary(International_Cargo_FTM_holtplot)


# Checking the residuals
checkresiduals(International_Cargo_FTM_holtplot)  # Not a white noise data

# Ploting the forecast model

autoplot(International_Cargo_FTM_holtplot) + 
  ggtitle("Holt Linear Trend : International Cargo - Revenue Freight Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")


# Holt-Winters with monthly data

# Plotting the Training data for Available Ton Miles
autoplot(Trainingdata_International_Cargo_ATM) +
  ggtitle("Training Data of International Cargo - Available Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")

# Applying the Holt's Linear trend Method for Available Ton Miles Data to produce a forecast of 5 years

International_Cargo_ATM_holtwinterplot <- hw(Trainingdata_International_Cargo_ATM, seasonal = "additive", h = 17)
International_Cargo_ATM_holtwinterplot


# Checking for residuals look like white noise

checkresiduals(International_Cargo_ATM_holtwinterplot)

International_Cargo_ATM_whitenoise <- FALSE # Close to randomness i.e white noise data just a fraction of true data.

International_Cargo_ATM_whitenoise

# Ploting the forecast

autoplot(International_Cargo_ATM_holtwinterplot) +
  ggtitle("Holt's Winter Trend : International Cargo - Available Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")



# Holt-Winters with monthly data

# Plotting the Training data for Freight Ton Miles
autoplot(Trainingdata_International_Cargo_FTM) +
  ggtitle("Training Data of International Cargo - Revenue Freight Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")

# Applying the Holt's Linear trend Method for Available Ton Miles Data to produce a forecast of 10 years

International_Cargo_FTM_holtwinterplot <- hw(Trainingdata_International_Cargo_FTM, seasonal = "additive", h = 17)
International_Cargo_FTM_holtwinterplot


# Checking for residuals look like white noise

checkresiduals(International_Cargo_FTM_holtwinterplot)

International_Cargo_FTM_whitenoise <- TRUE 

International_Cargo_FTM_whitenoise

# Ploting the forecast

autoplot(International_Cargo_FTM_holtwinterplot) +
  ggtitle("Holt's Winter Trend : International Cargo - Revenue Freight Ton Miles (January 2000 - February 2020)") +
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles") 



# Comparing the accuracy of Holt's Linear, Holt's Winter and Naive Method for Available Ton Miles

accuracy(International_Cargo_ATM_holtplot, Testingdata_International_Cargo_ATM)
accuracy(International_Cargo_ATM_holtwinterplot, Testingdata_International_Cargo_ATM)
accuracy(International_Cargo_ATM_naiveplot, Testingdata_International_Cargo_ATM)


# Saving the best forecast method for Available Ton Miles

International_Cargo_ATM_holt_holtwinter_naive_best <- International_Cargo_ATM_holtwinterplot


# Plotting the best accuracy plot

autoplot(International_Cargo_ATM_holt_holtwinter_naive_best) +
  ggtitle("Holt's Winter Trend : International Cargo - Available Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")


# Comparing the accuracy of Holt's Linear, Holt's Winter and Naive Method for Freight Ton Miles

accuracy(International_Cargo_FTM_holtplot, Testingdata_International_Cargo_FTM)
accuracy(International_Cargo_FTM_holtwinterplot, Testingdata_International_Cargo_FTM)
accuracy(International_Cargo_FTM_naiveplot, Testingdata_International_Cargo_FTM)


# Saving the best forecast method for Freight Ton Miles

International_Cargo_FTM_holt_holtwinter_naive_best <- International_Cargo_FTM_holtwinterplot



# Plotting the best accuracy plot

autoplot(International_Cargo_FTM_holt_holtwinter_naive_best) +
  ggtitle("Holt's Winter Trend : International Cargo - Revenue Freight Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")


# State Space Models for Exponential Smoothing



# Fit the ETS model to training data of International cargo ATM
International_Cargo_ATM_etsplot <- ets(Trainingdata_International_Cargo_ATM)

International_Cargo_ATM_etsplot  #ETS(M,Ad,M)

# Check the residuals
checkresiduals(International_Cargo_ATM_etsplot)  # not white noise data.


# Plot the forecast
autoplot(forecast(International_Cargo_ATM_etsplot)) +
  ggtitle("ETS Plot: International Cargo - Available Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")



# Fit the ETS model to training data of International cargo FTM
International_Cargo_FTM_etsplot <- ets(Trainingdata_International_Cargo_FTM)

International_Cargo_FTM_etsplot  #ETS(A,N,A)

# Check the residuals
checkresiduals(International_Cargo_FTM_etsplot)  # not white noise data.


# Plot the forecast
autoplot(forecast(International_Cargo_FTM_etsplot)) +
  ggtitle("ETS Plot: International Cargo - Revenue Freight Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")






# comparison between ETS vs seasonal naive method for International Cargo- Available Ton Miles

# Function to return ETS forecasts
International_Cargo_ATM_fets <- function(y, h) {
  forecast(ets(y), h = h)
}


# Apply tsCV() for both methods by computing cross-validated errors for up to 10 steps ahead
International_Cargo_ATM_tscv_ets_plot <- tsCV(Trainingdata_International_Cargo_ATM, International_Cargo_ATM_fets, h = 10)

autoplot(International_Cargo_ATM_tscv_ets_plot) +
  ggtitle("Time Series Cross Validation with ETS Plot : International Cargo Available Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")


International_Cargo_ATM_tscv_snaive_plot <- tsCV(Trainingdata_International_Cargo_ATM, snaive, h= 10)
autoplot(International_Cargo_ATM_tscv_snaive_plot) +
  ggtitle("Time Series Cross Validation with Seasonal Naive Plot : International Cargo Available Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")

# Compute MSE of resulting errors for International Cargo ATM (watch out for missing values)
mean(International_Cargo_ATM_tscv_ets_plot^2, na.rm = TRUE)
mean(International_Cargo_ATM_tscv_snaive_plot^2, na.rm = TRUE)

# Saving the best forecast method for Available Ton Miles

International_Cargo_ATM_tscv_ets_snaive_bestplot <- International_Cargo_ATM_tscv_ets_plot


autoplot(International_Cargo_ATM_tscv_ets_snaive_bestplot) +
  ggtitle("Time Series Cross Validation with ETS Plot : International Cargo Available Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")



# comparison between ETS vs seasonal naive method for International Cargo- Freight Ton Miles

# Function to return ETS forecasts
International_Cargo_FTM_fets <- function(y, h) {
  forecast(ets(y), h = h)
}


# Apply tsCV() for both methods by computing cross-validated errors for up to 10 steps ahead
International_Cargo_FTM_tscv_ets_plot <- tsCV(Trainingdata_International_Cargo_FTM, International_Cargo_FTM_fets, h = 10)

autoplot(International_Cargo_FTM_tscv_ets_plot) +
  ggtitle("Time Series Cross Validation with ETS Plot : International Cargo Revenue Freight Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")


International_Cargo_FTM_tscv_snaive_plot <- tsCV(Trainingdata_International_Cargo_FTM, snaive, h= 10)
autoplot(International_Cargo_FTM_tscv_snaive_plot) +
  ggtitle("Time Series Cross Validation with Seasonal Naive Plot : International Cargo Revenue Freight Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")

# Compute MSE of resulting errors for International Cargo FTM (watch out for missing values)
mean(International_Cargo_FTM_tscv_ets_plot^2, na.rm = TRUE)
mean(International_Cargo_FTM_tscv_snaive_plot^2, na.rm = TRUE)

# Saving the best forecast method for Freight Ton Miles

International_Cargo_FTM_tscv_ets_snaive_bestplot <- International_Cargo_FTM_tscv_ets_plot


autoplot(International_Cargo_FTM_tscv_ets_snaive_bestplot) +
  ggtitle("Time Series Cross Validation with ETS Plot : International Cargo Revenue Freight Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")



# Box-Cox transformations for time series

# Plotting the Training data for Available Ton Miles
autoplot(Trainingdata_International_Cargo_ATM) +
  ggtitle("Training Data of International Cargo - Available Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")

International_Cargo_ATM_BoxCoxtest <- BoxCox.lambda(Trainingdata_International_Cargo_ATM)

International_Cargo_ATM_BoxCoxtest # Close to lambda = 0 equivalent to log transformation 

# Plotting the Training data for Freight Ton Miles
autoplot(Trainingdata_International_Cargo_FTM) +
  ggtitle("Training Data of International Cargo - Revenue Freight Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")

International_Cargo_FTM_BoxCoxtest <- BoxCox.lambda(Trainingdata_International_Cargo_FTM)

International_Cargo_FTM_BoxCoxtest # Lambda equals � is like a square root plus linear transformation



# Non- Seasonal differencing for Stationarity

# Plotting the Training data for Available Ton Miles
autoplot(Trainingdata_International_Cargo_ATM) +
  ggtitle("Training Data of International Cargo - Available Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")


# Plot the differenced data for Available Ton Miles

autoplot(diff(Trainingdata_International_Cargo_ATM)) +
  ggtitle("Difference: Training Data of International Cargo - Available Ton Miles Jan 2000 to Aug 2017") +
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")


# Plotting the ACF of the differenced data for Available Ton Miles

ggAcf(diff(Trainingdata_International_Cargo_ATM)) +
  ggtitle("ACF Plot: International Cargo ATM")  #Not a white noise data.
 

# Non- Seasonal differencing for Stationarity


# Plotting the Training data for Freight Ton Miles
autoplot(Trainingdata_International_Cargo_FTM) +
  ggtitle("Training Data of International Cargo - Revenue Freight Ton Miles Jan 2000 to Aug 2017") +
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")


# Plot the differenced data for Freight Ton Miles

autoplot(diff(Trainingdata_International_Cargo_FTM)) +
  ggtitle(" Difference: Training Data of International Cargo - Revenue Freight Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")

# Plotting the ACF of the differenced data for Freight Ton Miles

ggAcf(diff(Trainingdata_International_Cargo_FTM)) +
  ggtitle("ACF Plot: International Cargo FTM")  #Not a white noise data.



# Seasonal differencing for stationarity

# Plotting the Training data for Available Ton Miles
autoplot(Trainingdata_International_Cargo_ATM) +
  ggtitle("Training Data of International Cargo - Available Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")


# Take logs and seasonal differences of training data of International Cargo Available Ton Miles
International_Cargo_ATM_diff_logplot <- diff(log(Trainingdata_International_Cargo_ATM), lag = 12)

# Plotting the Data
autoplot(International_Cargo_ATM_diff_logplot) +
  ggtitle("Difference Log Plot: Training Data of International Cargo - Available Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")

# Take another difference and plot
International_Cargo_ATM_difflog_plot <- diff(International_Cargo_ATM_diff_logplot)


autoplot(International_Cargo_ATM_difflog_plot) +
  ggtitle(" Second Difference Plot: Training Data of International Cargo - Available Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")


# Plotting the ACF of the data
ggAcf(International_Cargo_ATM_difflog_plot) +
  ggtitle("ACF plot of the difference of the logs and seasonal differences of training data of International Cargo Available Ton Miles") #Not white noise data



# Seasonal differencing for stationarity

# Plotting the Training data for Freight Ton Miles
autoplot(Trainingdata_International_Cargo_FTM) +
  ggtitle("Training Data of International Cargo - Freight Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")



# Take logs and seasonal differences of training data of International Cargo Freight Ton Miles
International_Cargo_FTM_diff_logplot <- diff(log(Trainingdata_International_Cargo_FTM), lag = 12)

# Plotting the Data
autoplot(International_Cargo_FTM_diff_logplot) +
  ggtitle("Difference Log Plot: Training Data of International Cargo - Revenue Freight Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")

# Take another difference and plot
International_Cargo_FTM_difflog_plot <- diff(International_Cargo_FTM_diff_logplot)

autoplot(International_Cargo_FTM_difflog_plot) +
  ggtitle(" Second Difference Plot: Training Data of International Cargo - Revenue Freight Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")


# Plotting the ACF of the data
ggAcf(International_Cargo_FTM_difflog_plot) +
  ggtitle("ACF plot of the difference of the logs and seasonal differences of training data of International Cargo Revenue Freight Ton Miles") #Not white noise data




# Automatic ARIMA models for seasonal time series S-ARIMA (p,d,q)(P,D,Q)[m]

#  Check that the logged raining data of International Cargo Available Ton Miles have a stable variance


International_Cargo_ATM_logplot <- autoplot(log(Trainingdata_International_Cargo_ATM)) +
  ggtitle("Log Plot: International Cargo - Available Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")

International_Cargo_ATM_logplot

# Fit a seasonal ARIMA model to data with lambda = 0

International_Cargo_ATM_autoarimaplot <- auto.arima(Trainingdata_International_Cargo_ATM, lambda = 0)

International_Cargo_ATM_autoarimaplot

# Checking the summary of the model

summary(International_Cargo_ATM_autoarimaplot)


# Recording the amount of lag-1 differencing and seasonal differencing used
International_Cargo_ATM_d <- 1
International_Cargo_ATM_D <- 1


# Plotting the Forecast for the next 2 years

autoplot(forecast(International_Cargo_ATM_autoarimaplot,h=24)) +
  ggtitle("Seasonal ARIMA Plot : International Cargo - Availble Ton Miles Forescast for next two years") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")



# Automatic ARIMA models for seasonal time series S-ARIMA (p,d,q)(P,D,Q)[m]

#  Check that the logged raining data of International Cargo Freight Ton Miles have a stable variance


International_Cargo_FTM_logplot <- autoplot(log(Trainingdata_International_Cargo_FTM)) +
  ggtitle("Log Plot: International Cargo - Revenue Freight Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")

International_Cargo_FTM_logplot

# Fit a seasonal ARIMA model to data with lambda = 0

International_Cargo_FTM_autoarimaplot <- auto.arima(Trainingdata_International_Cargo_FTM, lambda = 0)

International_Cargo_FTM_autoarimaplot

# Checking the summary of the model

summary(International_Cargo_FTM_autoarimaplot)


# Recording the amount of lag-1 differencing and seasonal differencing used
International_Cargo_FTM_d <- 1
International_Cargo_FTM_D <- 1


# Plotting the Forecast for the next 2 years

autoplot(forecast(International_Cargo_FTM_autoarimaplot,h=24)) +
  ggtitle("Seasonal ARIMA Plot : International Cargo - Revenue Freight Ton Miles Forescast for next two years") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")






# Comparing Auto.arima() and ets() for International Cargo ATM


# Auto.ARIMA() model without lambda consideration

International_Cargo_ATM_autoarima <- auto.arima(Trainingdata_International_Cargo_ATM)

International_Cargo_ATM_autoarima

# ETS() model for International Cargo ATM

International_Cargo_ATM_etsplot

# Checking the residuals for both the models

# For ARIMA Model
checkresiduals(International_Cargo_ATM_autoarima)  # Not a white noise data

# For ETS Model
checkresiduals(International_Cargo_ATM_etsplot) # Not White noise data

# Producing the forecast for each model

# For ARIMA Model
International_Cargo_ATM_autoarima_forecast <- forecast(International_Cargo_ATM_autoarima, h = 60)

autoplot(International_Cargo_ATM_autoarima_forecast) +
  ggtitle("Forecast Plot of Seasonal ARIMA model on Training data for International Cargo on  Available Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")

# For ETS Model
International_Cargo_ATM_ets_forecast <- forecast(International_Cargo_ATM_etsplot, h = 60)

autoplot(International_Cargo_ATM_ets_forecast) + 
  ggtitle("Forecast Plot of ETS model on Training data for International Cargo on Available Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")

# Using the accuracy () to find the best model  based on RMSE

# For ARIMA model
accuracy(International_Cargo_ATM_autoarima_forecast, Testingdata_International_Cargo_ATM)


# For ETS model
accuracy(International_Cargo_ATM_ets_forecast, Testingdata_International_Cargo_ATM)


# Saving the best model and plotting it

International_Cargo_ATM_autoarima_ets_bestplot <- International_Cargo_ATM_autoarima_forecast

autoplot(International_Cargo_ATM_autoarima_ets_bestplot) +
  ggtitle(" Best Plot : ARIMA model on Training data for Available Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")





# Comparing Auto.arima() and ets() for International Cargo FTM


# Auto.ARIMA() model without lambda consideration

International_Cargo_FTM_autoarima <- auto.arima(Trainingdata_International_Cargo_FTM)

International_Cargo_FTM_autoarima

# ETS() model for International Cargo FTM
International_Cargo_FTM_etsplot


# Checking the residuals for both the models

# For ARIMA Model
checkresiduals(International_Cargo_FTM_autoarima)  # white noise data

# For ETS Model
checkresiduals(International_Cargo_FTM_etsplot) # Not White noise data

# Producing the forecast for each model

# For ARIMA Model
International_Cargo_FTM_autoarima_forecast <- forecast(International_Cargo_FTM_autoarima, h = 60)

autoplot(International_Cargo_FTM_autoarima_forecast) +
  ggtitle("Forecast Plot of Seasonal ARIMA model on Training data of International Cargo for Revenue Freight Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")

# For ETS Model
International_Cargo_FTM_ets_forecast <- forecast(International_Cargo_FTM_etsplot, h = 60)

autoplot(International_Cargo_FTM_ets_forecast) + 
  ggtitle("Forecast Plot of ETS model on Training data of International Cargo for Revenue Freight Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")

# Using the accuracy () to find the best model  based on RMSE

# For ARIMA model
accuracy(International_Cargo_FTM_autoarima_forecast, Testingdata_International_Cargo_FTM)


# For ETS model
accuracy(International_Cargo_FTM_ets_forecast, Testingdata_International_Cargo_FTM)


# Saving the best model and plotting it

International_Cargo_FTM_autoarima_ets_bestplot <- International_Cargo_FTM_autoarima_forecast

autoplot(International_Cargo_FTM_autoarima_ets_bestplot) +
  ggtitle(" Best Plot : ARIMA model on Training data for Available Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")



# TBATS Model

# Plotting the Training data for Available Ton Miles
autoplot(Trainingdata_International_Cargo_ATM) +
  ggtitle("Training Data of International Cargo - Available Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")

# Fitting the TBATS model to the data

International_Cargo_ATM_tbatsmodel <- tbats(Trainingdata_International_Cargo_ATM)

# Forecasting the series for the next 5 years
International_Cargo_ATM_tbatsmodelforecast <- forecast(International_Cargo_ATM_tbatsmodel, h = 60)

# Plotting the forecast
autoplot(International_Cargo_ATM_tbatsmodelforecast) + 
  xlab("Year") +
  ylab(" International Cargo ATM: Total volume of Freight carried per Ton Miles")


# Record the Box-Cox parameter and the order of the Fourier terms
International_Cargo_ATM_lambda <- 0.006

International_Cargo_ATM_lambda

International_Cargo_ATM_K <- 5

International_Cargo_ATM_K


# Plotting the Training data for Freight Ton Miles
autoplot(Trainingdata_International_Cargo_FTM) +
  ggtitle("Training Data of International Cargo - Revenue Freight Ton Miles Jan 2000 to Aug 2017") +
  ylab("Total revenue earned from Freight carried per Ton Miles")

# Fitting the TBATS model to the data

International_Cargo_FTM_tbatsmodel <- tbats(Trainingdata_International_Cargo_FTM)

# Forecasting the series for the next 5 years

International_Cargo_FTM_tbatsmodelforecast <- forecast(International_Cargo_FTM_tbatsmodel, h = 60)

# Plotting the forecast
autoplot(International_Cargo_FTM_tbatsmodelforecast) +
  xlab("Year") +
  ylab(" International Cargo FTM: Total revenue earned from Freight carried per Ton Miles")

# Record the Box-Cox parameter and the order of the Fourier terms
International_Cargo_FTM_lambda <- 0.567

International_Cargo_FTM_lambda

International_Cargo_FTM_k <- 5

International_Cargo_FTM_k

# Neural Network Autoregression (NNAR) (p,P,size) Model for Available Ton Miles

# Applying the respective parameters of NNAR model which are 
# p: number of non-seasonal lags as inputs.
# P: number of seasonal lags as inputs.
# size: number of hidden nodes in the hidden layer

International_Cargo_ATM_nnarmodel <- nnetar(International_Cargo_ATM, p = 3, P = 1, size = 3)

International_Cargo_ATM_nnarmodel


# Checking the residuals of the model

checkresiduals(International_Cargo_ATM_nnarmodel) #Not a white noise data

# Producing the forecast for the next 5 years . Since it is monthly data we multiply the number of months into the number of respective years we want to forecast the model for

International_Cargo_ATM_nnarmodel_forecast <- forecast(International_Cargo_ATM_nnarmodel, h = 60)


# Producing the plot for International Cargo - Available Ton Miles

International_Cargo_ATM_nnarmodel_forecastplot <- autoplot(International_Cargo_ATM_nnarmodel_forecast) +
  ggtitle("NNAR model : International Cargo - Available Ton Miles - Forecast for next 5 years") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")


International_Cargo_ATM_nnarmodel_forecastplot # The results in the following plot where the blue curve shows the 5 year prediction.


# Producting the forecast with Prediction intervals for International Cargo Available Ton Miles.

International_Cargo_ATM_nnarmodel_forecast_predictionintervals <- forecast(International_Cargo_ATM_nnarmodel, PI = TRUE, h = 60)


# Producing the plot for International Cargo - Available Ton Miles with consideration of prediction intervals

International_Cargo_ATM_nnarmodel_forecast_predictionintervalsplot <- autoplot(International_Cargo_ATM_nnarmodel_forecast_predictionintervals) +
  ggtitle("NNAR model with Prediction Intervals: International Cargo - Available Ton Miles - Forecast for next 5 years") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")

International_Cargo_ATM_nnarmodel_forecast_predictionintervalsplot


# Now, changing the parameters of the NNAR model and cross validating this model, this time we 
# change the value of the repeat parameter as well which is nothing but the number of networks to fit with different random starting weights, which are the then averaged when producing the forecasts.
# By default the value of repeat is 20.

International_Cargo_ATM_nnarmodel_newparameters <- nnetar(Trainingdata_International_Cargo_ATM, p = 4, P = 2, size = 3, repeats = 30)

International_Cargo_ATM_nnarmodel_newparameters


# Checking the residuals of the model

checkresiduals(International_Cargo_ATM_nnarmodel_newparameters) #Not a white noise data


# Producing the forecast based on the new parameters for the next 5 years . Since it is monthly data we multiply the number of months into the number of respective years we want to forecast the model for

International_Cargo_ATM_nnarmodel_forecast_newparameters <- forecast(International_Cargo_ATM_nnarmodel_newparameters, h = 60)


# Producing the plot for International Cargo - Available Ton Miles based on the new parameters

International_Cargo_ATM_nnarmodel_forecast_newparameters_plot <- autoplot(International_Cargo_ATM_nnarmodel_forecast_newparameters) +
  ggtitle("NNAR model with New Parameters : Training Data International Cargo - Available Ton Miles - Forecast for next 5 years") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")


International_Cargo_ATM_nnarmodel_forecast_newparameters_plot # The results in the following plot where the blue curve shows the 5 year prediction.


# Producting the forecast based on the new parameters with Prediction intervals for International Cargo Available Ton Miles.

International_Cargo_ATM_nnarmodel_forecast_newparameters_predictionintervals <- forecast(International_Cargo_ATM_nnarmodel_newparameters, PI = TRUE, h = 60)


# Producing the plot for International Cargo - Available Ton Miles with consideration of prediction intervals

International_Cargo_ATM_nnarmodel_forecast_newparameters_predictionintervals_plot <- autoplot(International_Cargo_ATM_nnarmodel_forecast_newparameters_predictionintervals) +
  ggtitle("NNAR model for New Parameters with Prediction Intervals: Training Data International Cargo - Available Ton Miles - Forecast for next 5 years") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")

International_Cargo_ATM_nnarmodel_forecast_newparameters_predictionintervals_plot


# Producing the forecast Plot with consideration of the Testing Data of International Cargo ATM

autoplot(International_Cargo_ATM_nnarmodel_forecast_newparameters) +
  autolayer(Testingdata_International_Cargo_ATM, series = "Testing data of International Cargo ATM") +
  ggtitle("NNAR model Plot of Training Data International Cargo with consideration of the Testing Data of International Cargo - Available Ton Miles") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")


# Producing the forecast Plot with consideration of Prediction Intervals and with consideration of the Testing Data of International Cargo ATM

autoplot(International_Cargo_ATM_nnarmodel_forecast_newparameters_predictionintervals) +
  autolayer(Testingdata_International_Cargo_ATM, series = "Testing data of International Cargo ATM") +
  ggtitle("NNAR model of Training Data International Cargo with Prediction Intervals with consideration of the Testing Data of International Cargo - Available Ton Miles") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")


# Computing the  prediction intervals using simulation 
# where future sample paths are generated using bootstrapped residuals.
# Simulation of 10 possible future sample 
# For NNAR model - Available Ton Miles


# Simulating the next 5 years of monthly data of International cargo ATM using our neural network model created.

International_Cargo_ATM_nn = nnetar(International_Cargo_ATM, p = 4, P = 2, size = 3)
International_Cargo_ATM_simulation <- ts(matrix(0, nrow=60L, ncol=10L),start=end(International_Cargo_ATM)[1L],frequency=12)
for(i in seq(10)){
  International_Cargo_ATM_simulation[,i]=simulate(International_Cargo_ATM_nn,nsim=60L)
}
autoplot(International_Cargo_ATM)+autolayer(International_Cargo_ATM_simulation) + 
  ylab("Total volume of Freight carried per Ton Miles") + 
  xlab("Year") + 
  ggtitle("NNAR model : International Cargo - Available Ton Miles - Forecast for next 5 years with Simulation")


# Forecasting the Simulation Model by setting the Prediction Interval and for the period of next 5 years

International_Cargo_ATM_simulation_forecast <- forecast(International_Cargo_ATM_nn, PI = TRUE, h = 60)

International_Cargo_ATM_simulation_forecast

# Plotting the simulation of the Forecasting model by setting the Prediction Interval

autoplot(International_Cargo_ATM_simulation_forecast) +
  ggtitle("Simulation forecast of NNAR model with by setting the Prediction Interval : International Cargo - Available Ton Miles - Forecast for next 5 years") +
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")



# Comparing the accuracy of NNAR with Holt's Winter, ETS, ARIMA and TBATS model based on RMSE

accuracy(International_Cargo_ATM_nnarmodel_forecast_newparameters, Testingdata_International_Cargo_ATM)

accuracy(International_Cargo_ATM_holtwinterplot, Testingdata_International_Cargo_ATM)

accuracy(International_Cargo_ATM_ets_forecast, Testingdata_International_Cargo_ATM)

accuracy(International_Cargo_ATM_autoarima_forecast, Testingdata_International_Cargo_ATM)

accuracy(International_Cargo_ATM_tbatsmodelforecast , Testingdata_International_Cargo_ATM)

# Saving the Best Accuracy model

Internatioal_Cargo_ATM_nnar_holtwinter_ets_arima  <- International_Cargo_ATM_holtwinterplot

# Plotting the Best Accuracy model

autoplot(Internatioal_Cargo_ATM_nnar_holtwinter_ets_arima) +
  ggtitle(" Best Plot : Holt Winter model on Training data of International Cargo for Available Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")






# Neural Network Autoregression (NNAR) (p,P,size) Model for Freight Ton Miles

# Applying the respective parameters of NNAR model which are 
# p: number of non-seasonal lags as inputs.
# P: number of seasonal lags as inputs.
# size: number of hidden nodes in the hidden layer

International_Cargo_FTM_nnarmodel <- nnetar(International_Cargo_FTM, p = 3, P = 1, size = 3)

International_Cargo_FTM_nnarmodel


# Checking the residuals of the model

checkresiduals(International_Cargo_FTM_nnarmodel) #Not a white noise data

# Producing the forecast for the next 5 years . Since it is monthly data we multiply the number of months into the number of respective years we want to forecast the model for

International_Cargo_FTM_nnarmodel_forecast <- forecast(International_Cargo_FTM_nnarmodel, h = 60)


# Producing the plot for International Cargo - Freight Ton Miles

International_Cargo_FTM_nnarmodel_forecastplot <- autoplot(International_Cargo_FTM_nnarmodel_forecast) +
  ggtitle("NNAR model : International Cargo - Freight Ton Miles - Forecast for next 5 years") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")


International_Cargo_FTM_nnarmodel_forecastplot # The results in the following plot where the blue curve shows the 5 year prediction.


# Producting the forecast with Prediction intervals for International Cargo Available Ton Miles.

International_Cargo_FTM_nnarmodel_forecast_predictionintervals <- forecast(International_Cargo_FTM_nnarmodel, PI = TRUE, h = 60)


# Producing the plot for International Cargo - Available Ton Miles with consideration of prediction intervals

International_Cargo_FTM_nnarmodel_forecast_predictionintervalsplot <- autoplot(International_Cargo_FTM_nnarmodel_forecast_predictionintervals) +
  ggtitle("NNAR model with Prediction Intervals: International Cargo - Freight Ton Miles - Forecast for next 5 years") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")

International_Cargo_FTM_nnarmodel_forecast_predictionintervalsplot


# Now, changing the parameters of the NNAR model and cross validating this model, this time we 
# change the value of the repeat parameter as well which is nothing but the number of networks to fit with different random starting weights, which are the then averaged when producing the forecasts.
# By default the value of repeat is 20.

International_Cargo_FTM_nnarmodel_newparameters <- nnetar(Trainingdata_International_Cargo_FTM, p = 4, P = 2, size = 3, repeats = 30)

International_Cargo_FTM_nnarmodel_newparameters


# Checking the residuals of the model

checkresiduals(International_Cargo_FTM_nnarmodel_newparameters) #Not a white noise data


# Producing the forecast based on the new parameters for the next 5 years . Since it is monthly data we multiply the number of months into the number of respective years we want to forecast the model for

International_Cargo_FTM_nnarmodel_forecast_newparameters <- forecast(International_Cargo_FTM_nnarmodel_newparameters, h = 60)


# Producing the plot for International Cargo - Freight Ton Miles based on the new parameters

International_Cargo_FTM_nnarmodel_forecast_newparameters_plot <- autoplot(International_Cargo_FTM_nnarmodel_forecast_newparameters) +
  ggtitle("NNAR model with New Parameters : Training Data International Cargo - Revenue Freight Ton Miles - Forecast for next 5 years") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")


International_Cargo_FTM_nnarmodel_forecast_newparameters_plot # The results in the following plot where the blue curve shows the 5 year prediction.


# Producting the forecast based on the new parameters with Prediction intervals for International Cargo Freight Ton Miles.

International_Cargo_FTM_nnarmodel_forecast_newparameters_predictionintervals <- forecast(International_Cargo_FTM_nnarmodel_newparameters, PI = TRUE, h = 60)


# Producing the plot for International Cargo - Available Ton Miles with consideration of prediction intervals

International_Cargo_FTM_nnarmodel_forecast_newparameters_predictionintervals_plot <- autoplot(International_Cargo_FTM_nnarmodel_forecast_newparameters_predictionintervals) +
  ggtitle("NNAR model for New Parameters with Prediction Intervals: Training Data International Cargo - Revenue Freight Ton Miles - Forecast for next 5 years") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")

International_Cargo_FTM_nnarmodel_forecast_newparameters_predictionintervals_plot


# Producing the forecast Plot with consideration of the Testing Data of International Cargo FTM

autoplot(International_Cargo_FTM_nnarmodel_forecast_newparameters) +
  autolayer(Testingdata_International_Cargo_FTM, series = "Testing data of International Cargo FTM") +
  ggtitle("NNAR model Plot of Training Data International Cargo with consideration of the Testing Data of International Cargo - Revenue Freight Ton Miles") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")


# Producing the forecast Plot with consideration of Prediction Intervals and with consideration of the Testing Data of International Cargo ATM

autoplot(International_Cargo_FTM_nnarmodel_forecast_newparameters_predictionintervals) +
  autolayer(Testingdata_International_Cargo_FTM, series = "Testing data of International Cargo FTM") +
  ggtitle("NNAR model of Training Data International Cargo with Prediction Intervals with consideration of the Testing Data of International Cargo - Revenue Freight Ton Miles") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")


# Computing the  prediction intervals using simulation 
# where future sample paths are generated using bootstrapped residuals.
# Simulation of 10 possible future sample 
# For NNAR model - Freight Ton Miles


# Simulating the next 5 years of monthly data of International cargo FTM using our neural network model created.

International_Cargo_FTM_nn = nnetar(International_Cargo_FTM, p = 4, P = 2, size = 3)
International_Cargo_FTM_simulation <- ts(matrix(0, nrow=60L, ncol=10L),start=end(International_Cargo_FTM)[1L],frequency=12)
for(i in seq(10)){
  International_Cargo_FTM_simulation[,i]=simulate(International_Cargo_FTM_nn,nsim=60L)
}
autoplot(International_Cargo_FTM)+autolayer(International_Cargo_FTM_simulation) + 
  ylab("Total revenue earned from Freight carried per Ton Miles") + 
  xlab("Year") + 
  ggtitle("NNAR model : International Cargo - Freight Ton Miles - Forecast for next 5 years with Simulation")


# Forecasting the Simulation Model by setting the Prediction Interval and for the period of next 5 years

International_Cargo_FTM_simulation_forecast <- forecast(International_Cargo_FTM_nn, PI = TRUE, h = 60)

International_Cargo_FTM_simulation_forecast

# Plotting the simulation of the Forecasting model by setting the Prediction Interval

autoplot(International_Cargo_FTM_simulation_forecast) +
  ggtitle("Simulation forecast of NNAR model with by setting the Prediction Interval : International Cargo - Revenue Freight Ton Miles - Forecast for next 5 years") +
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")



# Comparing the accuracy of NNAR with Holt's Winter, ETS, ARIMA and TBATS model based on RMSE

accuracy(International_Cargo_FTM_nnarmodel_forecast_newparameters, Testingdata_International_Cargo_FTM)

accuracy(International_Cargo_FTM_holtwinterplot, Testingdata_International_Cargo_FTM)

accuracy(International_Cargo_FTM_ets_forecast, Testingdata_International_Cargo_FTM)

accuracy(International_Cargo_FTM_autoarima_forecast, Testingdata_International_Cargo_FTM)

accuracy(International_Cargo_FTM_tbatsmodelforecast , Testingdata_International_Cargo_FTM)

# Saving the Best Accuracy model

Internatioal_Cargo_FTM_nnar_holtwinter_ets_arima  <- International_Cargo_FTM_holtwinterplot

# Plotting the Best Accuracy model

autoplot(Internatioal_Cargo_FTM_nnar_holtwinter_ets_arima) +
  ggtitle(" Best Plot : Holt Winter model on Training data of International Cargo for Revenue Freight Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles") 



# Dynamic Harmonic Regression for International Cargo Available Ton Miles

# Plotting the Training data for Available Ton Miles
autoplot(Trainingdata_International_Cargo_ATM) +
  ggtitle("Training Data of International Cargo - Available Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")


# Four term (k) for International cargo Avilable Ton Miles as per the TBATS model
International_Cargo_ATM_K

# Setting up the Harmonic regressors of order Fourier Term (k)

International_Cargo_ATM_harmonics <- fourier(Trainingdata_International_Cargo_ATM, K = International_Cargo_ATM_K)

International_Cargo_ATM_harmonics

# Fitting the Dynamic Harmonic Regression model with ARIMA errors

International_Cargo_ATM_DynamicHarmonicRegression <- auto.arima(Trainingdata_International_Cargo_ATM, xreg = International_Cargo_ATM_harmonics, seasonal = FALSE)

International_Cargo_ATM_DynamicHarmonicRegression


# Forecasting For the next 5 years

International_Cargo_ATM_newharmonics <- fourier(Trainingdata_International_Cargo_ATM, K = International_Cargo_ATM_K, h = 60)

International_Cargo_ATM_DynamicHarmonicRegression_forecast <- forecast(International_Cargo_ATM_DynamicHarmonicRegression, xreg = International_Cargo_ATM_newharmonics)


# Plotting the Forcast of the Dynamic Regression Forecasting Model

autoplot(International_Cargo_ATM_DynamicHarmonicRegression_forecast) +
  ggtitle("Dynamic Harmonic Regression Model: International Cargo - Available Ton Miles") +
  ylab("Total volume of Freight carried per Ton Miles") +
  xlab(" Year ")


# Comparing the accuaracy of the model with Neural Network Auto Regression (NNAR) model for International Cargo - Available Ton Miles

accuracy(International_Cargo_ATM_nnarmodel_forecast_newparameters, Testingdata_International_Cargo_ATM)

accuracy(International_Cargo_ATM_DynamicHarmonicRegression_forecast, Testingdata_International_Cargo_ATM)


# Saving the best accuracy of the model

International_Cargo_ATM_nnar_dynamicharmonicregression_best <- International_Cargo_ATM_DynamicHarmonicRegression_forecast

# Plotting the Best Accuracy model

autoplot(International_Cargo_ATM_nnar_dynamicharmonicregression_best) +
  ggtitle(" Best Plot: Dynamic Harmonic Regression Model: International Cargo - Available Ton Miles") +
  ylab("Total volume of Freight carried per Ton Miles") +
  xlab(" Year ")




# Dynamic Harmonic Regression for International Cargo Freight Ton Miles

# Plotting the Training data for Freight Ton Miles
autoplot(Trainingdata_International_Cargo_FTM) +
  ggtitle("Training Data of International Cargo - Revenue Freight Ton Miles Jan 2000 to Aug 2017") + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")


# Four term (k) for International cargo Freight Ton Miles as per the TBATS model
International_Cargo_FTM_k

# Setting up the Harmonic regressors of order Fourier Term (k)

International_Cargo_FTM_harmonics <- fourier(Trainingdata_International_Cargo_FTM, K = International_Cargo_FTM_k)

International_Cargo_FTM_harmonics

# Fitting the Dynamic Harmonic Regression model with ARIMA errors

International_Cargo_FTM_DynamicHarmonicRegression <- auto.arima(Trainingdata_International_Cargo_FTM, xreg = International_Cargo_FTM_harmonics, seasonal = FALSE)

International_Cargo_FTM_DynamicHarmonicRegression


# Forecasting For the next 5 years

International_Cargo_FTM_newharmonics <- fourier(Trainingdata_International_Cargo_FTM, K = International_Cargo_FTM_k, h = 60)

International_Cargo_FTM_DynamicHarmonicRegression_forecast <- forecast(International_Cargo_FTM_DynamicHarmonicRegression, xreg = International_Cargo_FTM_newharmonics)


# Plotting the Forcast of the Dynamic Regression Forecasting Model

autoplot(International_Cargo_FTM_DynamicHarmonicRegression_forecast) +
  ggtitle("Dynamic Harmonic Regression Model: International Cargo - Revenue Freight Ton Miles") +
  ylab("Total revenue earned from Freight carried per Ton Miles") +
  xlab("Year")


# Comparing the accuaracy of the model with Neural Network Auto Regression (NNAR) model for International Cargo - Freight Ton Miles

accuracy(International_Cargo_FTM_nnarmodel_forecast_newparameters, Testingdata_International_Cargo_FTM)

accuracy(International_Cargo_FTM_DynamicHarmonicRegression_forecast, Testingdata_International_Cargo_FTM)


# Saving the best accuracy of the model

International_Cargo_FTM_nnar_dynamicharmonicregression_best <- International_Cargo_FTM_DynamicHarmonicRegression_forecast

# Plotting the Best Accuracy model

autoplot(International_Cargo_FTM_nnar_dynamicharmonicregression_best) +
  ggtitle(" Best Plot: Dynamic Harmonic Regression Model: International Cargo - Revenue Freight Ton Miles") +
  ylab("Total revenue earned from Freight carried per Ton Miles") +
  xlab("Year")





# Comparing all the forecasting model for Available Ton Miles

accuracy(International_Cargo_ATM_naiveplot, Testingdata_International_Cargo_ATM)

accuracy(International_Cargo_ATM_snaiveplot, Testingdata_International_Cargo_ATM)

accuracy(International_Cargo_ATM_meanplot, Testingdata_International_Cargo_ATM)

accuracy(International_Cargo_ATM_sesplot, Testingdata_International_Cargo_ATM)

accuracy(International_Cargo_ATM_holtplot, Testingdata_International_Cargo_ATM)

accuracy(International_Cargo_ATM_holtwinterplot, Testingdata_International_Cargo_ATM)

accuracy(International_Cargo_ATM_autoarima_forecast, Testingdata_International_Cargo_ATM)

accuracy(International_Cargo_ATM_ets_forecast, Testingdata_International_Cargo_ATM)

accuracy(International_Cargo_ATM_tbatsmodelforecast , Testingdata_International_Cargo_ATM)

accuracy(International_Cargo_ATM_nnarmodel_forecast_newparameters, Testingdata_International_Cargo_ATM)

accuracy(International_Cargo_ATM_DynamicHarmonicRegression_forecast, Testingdata_International_Cargo_ATM)

# Saving the best accuracy plot

International_Cargo_ATM_bestmodel <- International_Cargo_ATM_holtwinterplot

# Plotting the Best Accuracy Model

autoplot(International_Cargo_ATM_bestmodel) +
  ggtitle("Best Plot- Holt Winter Model: International Cargo - Available Ton Miles") +
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles")




# Comparing all the forecasting model for Freight Ton Miles

accuracy(International_Cargo_FTM_naiveplot, Testingdata_International_Cargo_FTM)

accuracy(International_Cargo_FTM_snaiveplot, Testingdata_International_Cargo_FTM)

accuracy(International_Cargo_FTM_meanplot, Testingdata_International_Cargo_FTM)

accuracy(International_Cargo_FTM_sesplot, Testingdata_International_Cargo_FTM)

accuracy(International_Cargo_FTM_holtplot, Testingdata_International_Cargo_FTM)

accuracy(International_Cargo_FTM_holtwinterplot, Testingdata_International_Cargo_FTM)

accuracy(International_Cargo_FTM_autoarima_forecast, Testingdata_International_Cargo_FTM)

accuracy(International_Cargo_FTM_ets_forecast, Testingdata_International_Cargo_FTM)

accuracy(International_Cargo_FTM_tbatsmodelforecast , Testingdata_International_Cargo_FTM)

accuracy(International_Cargo_FTM_nnarmodel_forecast_newparameters, Testingdata_International_Cargo_FTM)

accuracy(International_Cargo_FTM_DynamicHarmonicRegression_forecast, Testingdata_International_Cargo_FTM)


# Saving the best Accuracy plot

International_Cargo_FTM_bestmodel <- International_Cargo_FTM_holtwinterplot

# Plotting the Best Accuracy Model

autoplot(International_Cargo_FTM_bestmodel) +
  ggtitle("Best Plot- Holt Winter Model: International Cargo - Revenue Freight Ton Miles") +
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles")


