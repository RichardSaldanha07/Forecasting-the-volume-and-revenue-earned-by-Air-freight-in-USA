# Install the necessary packages for Time Series Analysis
install.packages("prophet")
install.packages("forecast")
install.packages("fpp2")
install.packages("lubridate")
install.packages("TSstudio")

#Import the installed packages for Time Series Analysis
library(lubridate)
library(readr)
library(ggplot2)
library(forecast)
library(prophet)
library(fpp2)
library(tidyverse)
library(caTools)
library(TSstudio)


# Loading the 6 csv files here ATM means Available Ton Miles, FTM means Freight Ton Miles for Domestic, International and System Cargo 
domesticcargo_ATM <- read.csv("Domesticcargo_ATM.csv")
internationalcargo_ATM <- read.csv("Internationalcargo_ATM.csv")
systemcargo_ATM <- read.csv("Systemcargo_ATM.csv")
domesticcargo_FTM <- read.csv("Domesticcargo_FTM.csv")
internationalcargo_FTM <- read.csv("Internationalcargo_FTM.csv")
systemcargo_FTM <- read.csv("Systemcargo_FTM.csv")


# To check the summary of the datasets 

summary(domesticcargo_ATM)
summary(internationalcargo_ATM)
summary(systemcargo_ATM)
summary(domesticcargo_FTM)
summary(internationalcargo_FTM)
summary(systemcargo_FTM)

# Checking for Null Values in the datasets

is.na(domesticcargo_ATM)
sum(is.na(domesticcargo_ATM))
head(domesticcargo_ATM)

is.na(internationalcargo_ATM)
sum(is.na(internationalcargo_ATM))
head(internationalcargo_ATM)

is.na(systemcargo_ATM)
sum(is.na(systemcargo_ATM))
head(systemcargo_ATM)

is.na(domesticcargo_FTM)
sum(is.na(domesticcargo_FTM))
head(domesticcargo_FTM)

is.na(internationalcargo_FTM)
sum(is.na(internationalcargo_FTM))
head(internationalcargo_FTM)

is.na(systemcargo_FTM)
sum(is.na(systemcargo_FTM))
head(systemcargo_FTM)



# Converting the Period feature of date format into correct date format for performing time series forecasting analysis

domesticcargo_ATM$Period <- dmy(domesticcargo_ATM$Period)
head(domesticcargo_ATM)
View(domesticcargo_ATM)
class(domesticcargo_ATM$Period)

internationalcargo_ATM$Period <- dmy(internationalcargo_ATM$Period)
head(internationalcargo_ATM)
View(internationalcargo_ATM)
class(internationalcargo_ATM$Period)

systemcargo_ATM$Period <- dmy(systemcargo_ATM$Period)
head(systemcargo_ATM)
View(systemcargo_ATM)
class(systemcargo_ATM$Period)

domesticcargo_FTM$Period <- dmy(domesticcargo_FTM$Period)
head(domesticcargo_FTM)
View(domesticcargo_FTM)
class(domesticcargo_FTM$Period)

internationalcargo_FTM$Period <- dmy(internationalcargo_FTM$Period)
head(internationalcargo_FTM)
View(internationalcargo_FTM)
class(internationalcargo_FTM$Period)

systemcargo_FTM$Period <- dmy(systemcargo_FTM$Period)
head(systemcargo_FTM)
View(systemcargo_FTM)
class(systemcargo_FTM$Period)


# Declare the datasets as time series data

Domestic_Cargo_ATM <- ts(domesticcargo_ATM[,4],frequency = 12, start = c(2000,1), end = c(2020,2))

International_Cargo_ATM <- ts(internationalcargo_ATM[,4],frequency = 12, start = c(2000,1), end = c(2020,2))

System_Cargo_ATM <- ts(systemcargo_ATM[,4],frequency = 12,start = c(2000,1), end = c(2020,2))

Domestic_Cargo_FTM <- ts(domesticcargo_FTM[,4],frequency = 12, start = c(2000,1), end = c(2020,2))

International_Cargo_FTM <- ts(internationalcargo_FTM[,4],frequency = 12, start = c(2000,1), end = c(2020,2))

System_Cargo_FTM <- ts(systemcargo_FTM[,4],frequency = 12,start = c(2000,1), end = c(2020,2))


# Perform preliminary Analysis on the datasets

# Time plots for the respective datasets

# In order to Display the values correctly we make use of the below command 
# So that R does not display values in Exponential Format

options(scipen=10000)

autoplot(Domestic_Cargo_ATM) + 
  ggtitle("Time Plot:Domestic Cargo - Available Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") + 
  ylab("Total volume of Freight carried per Ton Miles")

autoplot(International_Cargo_ATM) + 
  ggtitle("Time Plot: International Cargo - Available Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") + 
  ylab("Total volume of Freight carried per Ton Miles")

autoplot(System_Cargo_ATM) + 
  ggtitle("Time Plot: System Cargo -  Available Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") + 
  ylab("Total volume of Freight carried per Ton Miles")

autoplot(Domestic_Cargo_FTM) + 
  ggtitle("Time Plot:Domestic Cargo - Revenue Freight Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") + 
  ylab("Total revenue earned from Freight carried per Ton Miles")

autoplot(International_Cargo_FTM) + 
  ggtitle("Time Plot: International Cargo - Revenue Freight Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") + 
  ylab("Total revenue earned from Freight carried per Ton Miles")

autoplot(System_Cargo_FTM) + 
  ggtitle("Time Plot: System Cargo -  Revenue Freight Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") + 
  ylab("Total revenue earned from Freight carried per Ton Miles")



# The Datasets exhibits a strong trend. Investigate transformations.

#  We need to take out the first difference of the data in order to remove the trend

Domestic_ATM_Diff <- diff(Domestic_Cargo_ATM)
International_ATM_Diff <- diff(International_Cargo_ATM)
System_ATM_Diff <- diff(System_Cargo_ATM)
Domestic_FTM_Diff <- diff(Domestic_Cargo_FTM)
International_FTM_Diff <- diff(International_Cargo_FTM)
System_FTM_Diff <- diff(System_Cargo_FTM)

# Time plots of differenced data 

autoplot(Domestic_ATM_Diff) + 
  ggtitle("Time Plot: Domestic Cargo - Change in Available Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") + 
  ylab("Total volume of Freight carried per Ton Miles")

autoplot(International_ATM_Diff) + 
  ggtitle("Time Plot: International Cargo - Change in Available Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") + 
  ylab("Total volume of Freight carried per Ton Miles")

autoplot(System_ATM_Diff) + 
  ggtitle("Time Plot: System Cargo - Change in Available Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") + 
  ylab("Total volume of Freight carried per Ton Miles")

autoplot(Domestic_FTM_Diff) + 
  ggtitle("Time Plot: Domestic Cargo - Change in Revenue Freight Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") + 
  ylab("Total revenue earned from Freight carried per Ton Miles")

autoplot(International_FTM_Diff) + 
  ggtitle("Time Plot: International Cargo - Change in Revenue Freight Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") + 
  ylab("Total revenue earned from Freight carried per Ton Miles")

autoplot(System_FTM_Diff) + 
  ggtitle("Time Plot: System Cargo - Change in Revenue Freight Ton Miles (January 2000 - February 2020)") + 
  xlab("Year") + 
  ylab("Total revenue earned from Freight carried per Ton Miles")


# Series appears trend-stationary, use to investigate seasonality

ggseasonplot(Domestic_ATM_Diff, year.labels = TRUE, year.labels.left = TRUE) +
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles") + 
  ggtitle("Seasonal Plot: Domestic Cargo - Change in Available Ton Miles (January 2000 - February 2020)")
  

ggseasonplot(International_ATM_Diff, year.labels = TRUE, year.labels.left = TRUE) +
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles") + 
  ggtitle("Seasonal Plot: International Cargo - Change in Available Ton Miles (January 2000 - February 2020)")

ggseasonplot(System_ATM_Diff, year.labels = TRUE, year.labels.left = TRUE) +
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles") + 
  ggtitle("Seasonal Plot: System Cargo - Change in Available Ton Miles (January 2000 - February 2020)")


ggseasonplot(Domestic_FTM_Diff, year.labels = TRUE, year.labels.left = TRUE) +
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles") + 
  ggtitle("Seasonal Plot: Domestic Cargo - Change in Revenue Freight Ton Miles (January 2000 - February 2020)")

ggseasonplot(International_FTM_Diff, year.labels = TRUE, year.labels.left = TRUE) +
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles") + 
  ggtitle("Seasonal Plot: International Cargo - Change in Revenue Freight Ton Miles (January 2000 - February 2020)")

ggseasonplot(System_FTM_Diff, year.labels = TRUE, year.labels.left = TRUE) +
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles") + 
  ggtitle("Seasonal Plot: System Cargo - Change in Revenue Freight Ton Miles (January 2000 - February 2020)")


# Polar seasonal plots of monthly volume and revenue earned by US Air freight carries in accordance to
# Domestic, International and System Cargo


ggseasonplot(Domestic_ATM_Diff, polar = TRUE) +
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles") + 
  ggtitle("Polar Seasonal Plot: Domestic Cargo - Change in Available Ton Miles (January 2000 - February 2020)")

ggseasonplot(International_ATM_Diff, polar = TRUE) +
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles") + 
  ggtitle("Polar Seasonal Plot: International Cargo - Change in Available Ton Miles (January 2000 - February 2020)")

ggseasonplot(System_ATM_Diff, polar = TRUE) +
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles") + 
  ggtitle("Polar Seasonal Plot: System Cargo - Change in Available Ton Miles (January 2000 - February 2020)")


ggseasonplot(Domestic_FTM_Diff, polar = TRUE) +
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles") + 
  ggtitle("Polar Seasonal Plot: Domestic Cargo - Change in Revenue Freight Ton Miles (January 2000 - February 2020)")

ggseasonplot(International_FTM_Diff, polar = TRUE) +
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles") + 
  ggtitle("Polar Seasonal Plot: International Cargo - Change in Revenue Freight Ton Miles (January 2000 - February 2020)")

ggseasonplot(System_FTM_Diff, polar = TRUE) +
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles") + 
  ggtitle("Polar Seasonal Plot: System Cargo - Change in Revenue Freight Ton Miles (January 2000 - February 2020)")

# Applying another seasonal plot which is a subseries plot in order to investigate seasonal patterns in the 
# datasets where the data for each season are collected together in separate mini time slots


ggsubseriesplot(Domestic_ATM_Diff) + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles") + 
  ggtitle("Subseries Plot: Domestic Cargo - Change in Available Ton Miles (January 2000 - February 2020)")

ggsubseriesplot(International_ATM_Diff) + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles") + 
  ggtitle("Subseries Plot: International Cargo - Change in Available Ton Miles (January 2000 - February 2020)")

ggsubseriesplot(System_ATM_Diff) + 
  xlab("Year") +
  ylab("Total volume of Freight carried per Ton Miles") + 
  ggtitle("Subseries Plot: System Cargo - Change in Available Ton Miles (January 2000 - February 2020)")


ggsubseriesplot(Domestic_FTM_Diff) + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles") + 
  ggtitle("Subseries Plot: Domestic Cargo - Change in Revenue Freight Ton Miles (January 2000 - February 2020)")

ggsubseriesplot(International_FTM_Diff) + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles") + 
  ggtitle("Subseries Plot: International Cargo - Change in Revenue Freight Ton Miles (January 2000 - February 2020)")

ggsubseriesplot(System_FTM_Diff) + 
  xlab("Year") +
  ylab("Total revenue earned from Freight carried per Ton Miles") + 
  ggtitle("Subseries Plot: System Cargo - Change in Revenue Freight Ton Miles (January 2000 - February 2020)")



# Merging the datasets into respective aspects so that we can examine for multi variate analysis.

# Domestic Cargo
domesticcargo_merge <- merge(domesticcargo_ATM,domesticcargo_FTM,by=c('Period'),all.x=T)
head(domesticcargo_merge)
View(domesticcargo_merge)

Domesticcargo <- domesticcargo_merge %>%
  rename(Volume_Scheduled = Scheduled.x,
         Volume_Non.Scheduled = Non.Scheduled.x,
         Volume_Total = Total.x,
         Revenue_Scheduled = Scheduled.y,
         Revenue_Non.Scheduled = Non.Scheduled.y,
         Revenue_Total = Total.y
         )

head(Domesticcargo)
View(Domesticcargo)


# International Cargo
internationalcargo_merge <- merge(internationalcargo_ATM,internationalcargo_FTM,by=c('Period'),all.x = T)
head(internationalcargo_merge)
View(internationalcargo_merge)

Internationalcargo <- internationalcargo_merge %>%
  rename(Volume_Scheduled = Scheduled.x,
         Volume_Non.Scheduled = Non.Scheduled.x,
         Volume_Total = Total.x,
         Revenue_Scheduled = Scheduled.y,
         Revenue_Non.Scheduled = Non.Scheduled.y,
         Revenue_Total = Total.y
  )

head(Internationalcargo)
View(Internationalcargo)

# System Cargo
systemcargo_merge <- merge(systemcargo_ATM,systemcargo_FTM,by=c('Period'),all.x = T)
head(systemcargo_merge)
View(systemcargo_merge)

Systemcargo <- systemcargo_merge %>%
  rename(Volume_Scheduled = Scheduled.x,
         Volume_Non.Scheduled = Non.Scheduled.x,
         Volume_Total = Total.x,
         Revenue_Scheduled = Scheduled.y,
         Revenue_Non.Scheduled = Non.Scheduled.y,
         Revenue_Total = Total.y
  )

head(Systemcargo)
View(Systemcargo)

# Saving the dataframe into csv for further analysis

write.csv(Domesticcargo,"E:\\Thesis\\Project\\Domestic_Cargo.csv", row.names = FALSE)

write.csv(Internationalcargo,"E:\\Thesis\\Project\\International_Cargo.csv", row.names = FALSE)

write.csv(Systemcargo,"E:\\Thesis\\Project\\System_Cargo.csv", row.names = FALSE)

# Importing the new datasets

# Domestic Cargo
Domestic_Cargo <- read.csv("Domestic_Cargo.csv")
View(Domestic_Cargo)
summary(Domestic_Cargo)

# International Cargo
International_Cargo <- read.csv("International_Cargo.csv")
View(International_Cargo)
summary(International_Cargo)

#System Cargo
System_Cargo <- read.csv("System_Cargo.csv")
View(System_Cargo)
summary(System_Cargo)


# Understanding the relationship between the Total Volume and Total Revenue earned in each respective
# sectors which are Domestic, International and System Cargo by US Air Carriers


# For Domestic Cargo
qplot(Volume_Total, Revenue_Total, data = as.data.frame(Domestic_Cargo)) +
  ggtitle("Domestic Cargo (January 2000 - February 2020)") +
  ylab("Total Revenue (January 2000 - February 2020)") + 
  xlab("Total Volume (January 2000 - February 2020)")

# For International Cargo
qplot(Volume_Total, Revenue_Total, data = as.data.frame(International_Cargo)) +
  ggtitle("International Cargo (January 2000 - February 2020)") +
  ylab("Total Revenue (January 2000 - February 2020)") + 
  xlab("Total Volume (January 2000 - February 2020)")

# For System Cargo
qplot(Volume_Total, Revenue_Total, data = as.data.frame(System_Cargo)) +
  ggtitle("System Cargo (January 2000 - February 2020)") +
  ylab("Total Revenue (January 2000 - February 2020)") + 
  xlab("Total Volume (January 2000 - February 2020)")

# Another way of plotting data for analysis

# Domestic Cargo
Data_Domestic_Cargo <- data.frame(Domestic_Cargo$Volume_Total,Domestic_Cargo$Revenue_Total)
Data_Domestic_Cargo_Plot <- ts(Data_Domestic_Cargo,frequency = 12, start = 2000, end = 2020)
plot(Data_Domestic_Cargo_Plot)

autoplot(Data_Domestic_Cargo_Plot) + 
  xlab("Year") +
  ylab("Total Volume and Revenue earned by Domestic Cargo") + 
  ggtitle("Domestic Cargo Records (January 2000 - February 2020)")


# International Cargo
Data_International_Cargo <- data.frame(International_Cargo$Volume_Total,International_Cargo$Revenue_Total)
Data_International_Cargo_Plot <- ts(Data_International_Cargo,frequency = 12, start = 2000, end = 2020)
plot(Data_International_Cargo_Plot)

autoplot(Data_International_Cargo_Plot) + 
  xlab("Year") +
  ylab("Total Volume and Revenue earned by International Cargo") + 
  ggtitle("International Cargo Records (January 2000 - February 2020)")


# System Cargo
Data_System_Cargo <- data.frame(System_Cargo$Volume_Total,System_Cargo$Revenue_Total)
Data_System_Cargo_Plot <- ts(Data_System_Cargo,frequency = 12, start = 2000, end = 2020)
plot(Data_System_Cargo_Plot)

autoplot(Data_System_Cargo_Plot) + 
  xlab("Year") +
  ylab("Total Volume and Revenue earned by International Cargo") + 
  ggtitle("International Cargo Records (January 2000 - February 2020)")


# In order to check whether the data frame is of time series object we make use of the is.ts() function
# It returns a boolean results in which True indicate a time series object and False indicates a non time series object

# Domestic Cargo
is.ts(Data_Domestic_Cargo_Plot) # Time Series Data object

# International Cargo
is.ts(Data_International_Cargo_Plot) # Time Series Data object

# System Cargo
is.ts(Data_System_Cargo_Plot) # Time Series Data object

#Performing sample transformation

# We will make use of the log() function in order to linearize a rapid trend

# Domestic Cargo
Log_Domestic_Cargo <- log(Data_Domestic_Cargo_Plot)
plot(Log_Domestic_Cargo)
autoplot(Log_Domestic_Cargo) + 
  xlab("Year") +
  ylab("Total Volume and Revenue earned by Domestic Cargo") + 
  ggtitle("Domestic Cargo Records (January 2000 - February 2020)")

# International Cargo
Log_International_Cargo <- log(Data_International_Cargo_Plot)
plot(Log_International_Cargo)
autoplot(Log_International_Cargo) + 
  xlab("Year") +
  ylab("Total Volume and Revenue earned by International Cargo") + 
  ggtitle("International Cargo Records (January 2000 - February 2020)")


# System Cargo
Log_System_Cargo <- log(Data_System_Cargo_Plot)
plot(Log_System_Cargo)
autoplot(Log_System_Cargo) + 
  xlab("Year") +
  ylab("Total Volume and Revenue earned by System Cargo") + 
  ggtitle("System Cargo Records (January 2000 - February 2020)")

# We use the diff() function in order to remove the linear trends

# Domestic Cargo
Diff_Domestic_Cargo <- diff(Data_Domestic_Cargo_Plot)
plot(Diff_Domestic_Cargo)
autoplot(Diff_Domestic_Cargo) + 
  xlab("Year") +
  ylab("Total Volume and Revenue earned by Domestic Cargo") + 
  ggtitle(" Difference: Domestic Cargo Records (January 2000 - February 2020)")

# International Cargo
Diff_International_Cargo <- diff(Data_International_Cargo_Plot)
plot(Diff_International_Cargo)
autoplot(Diff_International_Cargo) + 
  xlab("Year") +
  ylab("Total Volume and Revenue earned by International Cargo") + 
  ggtitle(" Difference: International Cargo Records (January 2000 - February 2020)")


# System Cargo
Diff_System_Cargo <- diff(Data_System_Cargo_Plot)
plot(Diff_System_Cargo)
autoplot(Diff_System_Cargo) + 
  xlab("Year") +
  ylab("Total Volume and Revenue earned by System Cargo") + 
  ggtitle("Difference: System Cargo Records (January 2000 - February 2020)")


# We use the length function in order to calculate the number of obervations in original data and 
# after applying the difference diff() function

# Domestic Cargo
length(Data_Domestic_Cargo_Plot)
length(Diff_Domestic_Cargo)

# International Cargo
length(Data_International_Cargo_Plot)
length(Diff_International_Cargo)

# System Cargo
length(Data_System_Cargo_Plot)
length(Diff_System_Cargo)


# The diff(,lag) where lag is the seasonal argument can remove periodic trends - Seasonal periodic trends

# Removing Seasonal trends with seasonal differencing for our multivariate time series for domestic,
# international and system cargo


# Domestic Cargo
Diff_Seasonal_Domestic_Cargo <- diff(Data_Domestic_Cargo_Plot, lag = 12)
plot(Diff_Seasonal_Domestic_Cargo)
autoplot(Diff_Seasonal_Domestic_Cargo) + 
  xlab("Year") +
  ylab("Total Volume and Revenue earned by Domestic Cargo") + 
  ggtitle(" Seasonal Difference: Domestic Cargo Records (January 2000 - February 2020)")


# International Cargo
Diff_Seasonal_International_Cargo <- diff(Data_International_Cargo_Plot, lag = 12)
plot(Diff_Seasonal_International_Cargo)
autoplot(Diff_Seasonal_International_Cargo) + 
  xlab("Year") +
  ylab("Total Volume and Revenue earned by International Cargo") + 
  ggtitle(" Seasonal Difference: International Cargo Records (January 2000 - February 2020)")

# System Cargo
Diff_Seasonal_System_Cargo <- diff(Data_System_Cargo_Plot, lag = 12)
plot(Diff_Seasonal_System_Cargo)
autoplot(Diff_Seasonal_System_Cargo) + 
  xlab("Year") +
  ylab("Total Volume and Revenue earned by System Cargo") + 
  ggtitle(" Seasonal Difference: System Cargo Records (January 2000 - February 2020)")


# Applying the length function in order to calculate the number of observations in original data and 
# after applying the difference diff() function with seasonal difference

# Domestic Cargo
length(Data_Domestic_Cargo_Plot)
length(Diff_Seasonal_Domestic_Cargo)

# International Cargo
length(Data_International_Cargo_Plot)
length(Diff_Seasonal_International_Cargo)

# System Cargo

length(Data_System_Cargo_Plot)
length(Diff_Seasonal_System_Cargo)


